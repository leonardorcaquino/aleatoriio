﻿"""Kedro settings placeholder.

Add project hooks, custom resolvers and catalog configuration here when implementation starts.
"""
