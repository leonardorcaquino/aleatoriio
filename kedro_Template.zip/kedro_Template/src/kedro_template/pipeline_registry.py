"""Pipeline registry.

The dynamic Databricks factory is built at runtime with real metadata and Spark
objects. Kedro still expects this module to exist, so the default registry keeps
an empty pipeline and exposes a helper for Databricks entrypoints.
"""

from __future__ import annotations

from typing import Any

from kedro.pipeline import Pipeline

from kedro_template.pipeline_factory.config_loader import ConfigLoader
from kedro_template.pipeline_factory.pipeline_builder import PipelineBuilder


def register_pipelines() -> dict[str, Pipeline]:
    """Register static project pipelines."""
    return {"__default__": Pipeline([])}


def build_dynamic_pipelines(
    spark: Any,
    catalog: Any | None = None,
    active_only: bool = True,
    write_options: dict[str, Any] | None = None,
) -> dict[str, Pipeline]:
    """Load metadata and build runtime Kedro pipelines for Databricks jobs."""
    bundle = ConfigLoader(catalog=catalog, spark=spark).load(active_only=active_only)
    return PipelineBuilder(
        spark=spark,
        bundle=bundle,
        write_options=write_options,
    ).build_all()
