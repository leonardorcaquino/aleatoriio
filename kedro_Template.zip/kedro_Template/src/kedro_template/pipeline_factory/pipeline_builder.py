"""Build Kedro pipelines dynamically from metadata."""

from __future__ import annotations

from typing import Any

from kedro.pipeline import Pipeline

from .models import MetadataBundle
from .node_builder import NodeBuilder, NodeFunction


class PipelineBuilder:
    """Create Kedro Pipeline objects from a metadata bundle."""

    def __init__(
        self,
        spark: Any,
        bundle: MetadataBundle,
        write_options: dict[str, Any] | None = None,
        custom_functions: dict[str, NodeFunction] | None = None,
    ) -> None:
        self.spark = spark
        self.bundle = bundle
        self.node_builder = NodeBuilder(
            spark=spark,
            bundle=bundle,
            write_options=write_options,
            custom_functions=custom_functions,
        )

    def build_all(self) -> dict[str, Pipeline]:
        """Build all active pipelines and a __default__ pipeline."""
        pipelines = {
            pipeline_id: self.build_pipeline(pipeline_id)
            for pipeline_id, pipeline in self.bundle.pipelines.items()
            if pipeline.is_active
        }
        pipelines["__default__"] = self._combine(pipelines.values())
        return pipelines

    def build_pipeline(self, pipeline_id: str) -> Pipeline:
        """Build a single Kedro Pipeline from cfg_node rows."""
        if pipeline_id not in self.bundle.pipelines:
            raise KeyError(f"Unknown pipeline_id: {pipeline_id}")

        kedro_nodes = []
        upstream_output: str | None = None
        for node_spec in self.bundle.nodes_for_pipeline(pipeline_id):
            kedro_node, upstream_output = self.node_builder.build(node_spec, upstream_output)
            kedro_nodes.append(kedro_node)
        return Pipeline(kedro_nodes)

    def _combine(self, pipelines: Any) -> Pipeline:
        combined = Pipeline([])
        for pipeline in pipelines:
            combined += pipeline
        return combined
