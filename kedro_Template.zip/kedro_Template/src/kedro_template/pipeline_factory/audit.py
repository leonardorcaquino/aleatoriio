"""Audit logging helpers for pipeline and node executions."""

from __future__ import annotations

from dataclasses import asdict
from datetime import datetime, timezone
from typing import Any
from uuid import uuid4

from .models import AuditEvent


def new_execution_id() -> str:
    """Create a unique execution identifier."""
    return str(uuid4())


def utc_now() -> datetime:
    """Return a timezone-aware UTC timestamp."""
    return datetime.now(timezone.utc)


class AuditLogger:
    """Append pipeline execution events to a Delta audit table."""

    def __init__(self, spark: Any, table_name: str) -> None:
        self.spark = spark
        self.table_name = table_name

    def running(
        self,
        execution_id: str,
        pipeline_id: str,
        node_id: str | None = None,
    ) -> AuditEvent:
        """Create and persist a running event."""
        event = AuditEvent(
            execution_id=execution_id,
            pipeline_id=pipeline_id,
            node_id=node_id,
            status="running",
            started_at=utc_now(),
        )
        self.write(event)
        return event

    def success(
        self,
        started_event: AuditEvent,
        source_count: int | None = None,
        target_count: int | None = None,
        rejected_count: int | None = None,
        watermark_start: str | None = None,
        watermark_end: str | None = None,
    ) -> AuditEvent:
        """Create and persist a success event for a previous running event."""
        event = AuditEvent(
            **{
                **asdict(started_event),
                "status": "success",
                "finished_at": utc_now(),
                "source_count": source_count,
                "target_count": target_count,
                "rejected_count": rejected_count,
                "watermark_start": watermark_start,
                "watermark_end": watermark_end,
            }
        )
        self.write(event)
        return event

    def failed(self, started_event: AuditEvent, error: Exception) -> AuditEvent:
        """Create and persist a failure event for a previous running event."""
        event = AuditEvent(
            **{
                **asdict(started_event),
                "status": "failed",
                "finished_at": utc_now(),
                "error_message": str(error),
            }
        )
        self.write(event)
        return event

    def write(self, event: AuditEvent) -> None:
        """Append one audit event to the configured table."""
        dataframe = self.spark.createDataFrame([asdict(event)])
        dataframe.write.format("delta").mode("append").saveAsTable(self.table_name)
