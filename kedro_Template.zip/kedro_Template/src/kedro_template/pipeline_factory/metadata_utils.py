"""Small normalization helpers for metadata tables."""

from __future__ import annotations

import json
from dataclasses import fields, is_dataclass
from typing import Any, TypeVar

T = TypeVar("T")


def parse_bool(value: Any, default: bool = False) -> bool:
    """Convert metadata booleans from common table encodings."""
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    if isinstance(value, int | float):
        return bool(value)
    if isinstance(value, str):
        return value.strip().lower() in {"1", "true", "t", "yes", "y", "sim", "s"}
    return default


def parse_json_object(value: Any) -> dict[str, Any]:
    """Parse an object stored as JSON, returning an empty dict for blanks."""
    if value is None or value == "":
        return {}
    if isinstance(value, dict):
        return value
    if isinstance(value, str):
        parsed = json.loads(value)
        if not isinstance(parsed, dict):
            raise ValueError(f"Expected JSON object, got {type(parsed).__name__}")
        return parsed
    raise TypeError(f"Cannot parse {type(value).__name__} as JSON object")


def parse_string_list(value: Any) -> list[str]:
    """Parse arrays stored as lists, JSON arrays or comma-separated strings."""
    if value is None or value == "":
        return []
    if isinstance(value, list | tuple | set):
        return [str(item) for item in value if item is not None and str(item) != ""]
    if isinstance(value, str):
        text = value.strip()
        if not text:
            return []
        if text.startswith("["):
            parsed = json.loads(text)
            if not isinstance(parsed, list):
                raise ValueError("Expected JSON array")
            return [str(item) for item in parsed]
        return [item.strip() for item in text.split(",") if item.strip()]
    return [str(value)]


def clean_record(record: dict[str, Any]) -> dict[str, Any]:
    """Drop Spark Row internals and normalize empty strings to None."""
    return {
        key: (None if value == "" else value)
        for key, value in record.items()
        if not key.startswith("__")
    }


def rows_to_records(data: Any) -> list[dict[str, Any]]:
    """Convert Spark/Pandas/list records into a list of dictionaries."""
    if data is None:
        return []
    if isinstance(data, list):
        return [clean_record(dict(item)) for item in data]
    if hasattr(data, "collect"):
        return [clean_record(row.asDict(recursive=True)) for row in data.collect()]
    if hasattr(data, "toPandas"):
        return [clean_record(row) for row in data.toPandas().to_dict(orient="records")]
    raise TypeError(f"Unsupported metadata container: {type(data).__name__}")


def dataclass_from_record(model: type[T], record: dict[str, Any]) -> T:
    """Build a dataclass from a record, ignoring unknown metadata columns."""
    if not is_dataclass(model):
        raise TypeError(f"{model!r} is not a dataclass")
    allowed = {field.name for field in fields(model)}
    return model(**{key: value for key, value in record.items() if key in allowed})
