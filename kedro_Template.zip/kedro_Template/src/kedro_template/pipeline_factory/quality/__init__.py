﻿"""Data quality rule execution."""
