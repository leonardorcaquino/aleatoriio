"""Run data quality checks from cfg_quality_rule metadata."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from pyspark.sql import functions as F

from ..models import QualityRuleSpec


class DataQualityError(ValueError):
    """Raised when a quality rule fails with fail_pipeline behavior."""


@dataclass(frozen=True)
class QualityResult:
    """Result of a single quality rule execution."""

    rule_id: str
    status: str
    failed_count: int
    total_count: int
    failure_ratio: float
    severity: str
    message: str


class QualityRuleRunner:
    """Execute common quality rules against Spark DataFrames."""

    def run(self, dataframe: Any, rules: list[QualityRuleSpec]) -> tuple[Any, list[QualityResult]]:
        """Run rules and return the original DataFrame plus rule results."""
        results = [self._run_rule(dataframe, rule) for rule in rules]
        failures = [
            result
            for result in results
            if result.status == "failed"
            and self._rule_by_id(rules, result.rule_id).on_failure == "fail_pipeline"
        ]
        if failures:
            messages = "; ".join(result.message for result in failures)
            raise DataQualityError(messages)
        return dataframe, results

    def _run_rule(self, dataframe: Any, rule: QualityRuleSpec) -> QualityResult:
        total_count = dataframe.count()
        failed_dataframe = self._failed_rows(dataframe, rule)
        failed_count = failed_dataframe.count()
        failure_ratio = 0.0 if total_count == 0 else failed_count / total_count
        status = "failed" if failure_ratio > rule.threshold else "passed"
        message = (
            f"Rule {rule.rule_id} {status}: {failed_count}/{total_count} rows failed "
            f"({failure_ratio:.4f})"
        )
        return QualityResult(
            rule_id=rule.rule_id,
            status=status,
            failed_count=failed_count,
            total_count=total_count,
            failure_ratio=failure_ratio,
            severity=rule.severity,
            message=message,
        )

    def _failed_rows(self, dataframe: Any, rule: QualityRuleSpec) -> Any:
        if rule.rule_type == "not_null":
            self._require_column(rule)
            return dataframe.where(F.col(rule.column_name).isNull())
        if rule.rule_type == "unique":
            self._require_column(rule)
            duplicated = (
                dataframe.groupBy(rule.column_name)
                .count()
                .where(F.col("count") > 1)
                .select(rule.column_name)
            )
            return dataframe.join(duplicated, on=rule.column_name, how="inner")
        if rule.rule_type == "accepted_values":
            self._require_column(rule)
            accepted_values = [
                value.strip()
                for value in (rule.rule_expression or "").split(",")
                if value.strip()
            ]
            return dataframe.where(~F.col(rule.column_name).isin(accepted_values))
        if rule.rule_type == "regex":
            self._require_column(rule)
            return dataframe.where(~F.col(rule.column_name).rlike(rule.rule_expression or ".*"))
        if rule.rule_type == "range":
            self._require_column(rule)
            min_value, max_value = (rule.rule_expression or "").split(",", maxsplit=1)
            return dataframe.where(
                (F.col(rule.column_name) < F.lit(float(min_value)))
                | (F.col(rule.column_name) > F.lit(float(max_value)))
            )
        if rule.rule_type == "custom_sql":
            if not rule.rule_expression:
                raise ValueError(f"Rule {rule.rule_id} requires rule_expression")
            return dataframe.where(f"NOT ({rule.rule_expression})")
        raise ValueError(f"Unsupported quality rule type: {rule.rule_type}")

    def _require_column(self, rule: QualityRuleSpec) -> None:
        if not rule.column_name:
            raise ValueError(f"Rule {rule.rule_id} requires column_name")

    def _rule_by_id(self, rules: list[QualityRuleSpec], rule_id: str) -> QualityRuleSpec:
        return next(rule for rule in rules if rule.rule_id == rule_id)
