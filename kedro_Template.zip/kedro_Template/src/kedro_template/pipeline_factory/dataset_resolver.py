"""Resolve Unity Catalog tables and ADLS paths from dataset metadata."""

from __future__ import annotations

from typing import Any

from .models import DatasetSpec


class DatasetResolver:
    """Read and write datasets declared in cfg_dataset."""

    def __init__(self, spark: Any) -> None:
        self.spark = spark

    def read(self, dataset: DatasetSpec, where: str | None = None) -> Any:
        """Read a dataset as a Spark DataFrame."""
        if dataset.read_mode == "query":
            query = dataset.storage_path or dataset.full_table_name
            dataframe = self.spark.sql(query)
        elif dataset.read_mode == "path":
            dataframe = self.spark.read.format(dataset.format).load(dataset.storage_path)
        else:
            dataframe = self.spark.table(dataset.full_table_name)

        if where:
            dataframe = dataframe.where(where)
        return dataframe

    def write_append(
        self,
        dataframe: Any,
        dataset: DatasetSpec,
        options: dict[str, Any] | None = None,
    ) -> None:
        """Append a Spark DataFrame to a Delta table."""
        self._save(self._writer(dataframe, dataset, options).mode("append"), dataset)

    def write_overwrite(
        self,
        dataframe: Any,
        dataset: DatasetSpec,
        options: dict[str, Any] | None = None,
    ) -> None:
        """Overwrite a Delta table."""
        self._save(self._writer(dataframe, dataset, options).mode("overwrite"), dataset)

    def optimize(self, dataset: DatasetSpec, zorder_columns: list[str] | None = None) -> None:
        """Run Databricks OPTIMIZE for a Delta table."""
        if not zorder_columns:
            self.spark.sql(f"OPTIMIZE {dataset.full_table_name}")
            return
        columns = ", ".join(zorder_columns)
        self.spark.sql(f"OPTIMIZE {dataset.full_table_name} ZORDER BY ({columns})")

    def vacuum(self, dataset: DatasetSpec, retention_hours: int) -> None:
        """Run Databricks VACUUM for a Delta table."""
        self.spark.sql(f"VACUUM {dataset.full_table_name} RETAIN {retention_hours} HOURS")

    def _writer(
        self,
        dataframe: Any,
        dataset: DatasetSpec,
        options: dict[str, Any] | None = None,
    ) -> Any:
        writer = dataframe.write.format(dataset.format)
        for key, value in (options or {}).items():
            writer = writer.option(key, value)
        if dataset.partition_columns:
            writer = writer.partitionBy(*dataset.partition_columns)
        return writer

    def _save(self, writer: Any, dataset: DatasetSpec) -> None:
        if dataset.write_mode == "path" and dataset.storage_path:
            writer.save(dataset.storage_path)
            return
        writer.saveAsTable(dataset.full_table_name)
