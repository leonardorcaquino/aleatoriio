"""Load and validate pipeline factory metadata from Delta tables."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from .metadata_utils import (
    dataclass_from_record,
    parse_bool,
    parse_json_object,
    parse_string_list,
    rows_to_records,
)
from .models import (
    ColumnMappingSpec,
    DatasetSpec,
    LoadStrategySpec,
    MetadataBundle,
    MetadataRecord,
    NodeSpec,
    PipelineSpec,
    QualityRuleSpec,
)


class MetadataValidationError(ValueError):
    """Raised when metadata tables are inconsistent."""


class ConfigLoader:
    """Load pipeline factory metadata from Kedro catalog entries or Spark tables."""

    table_names = {
        "pipelines": "cfg_pipeline",
        "datasets": "cfg_dataset",
        "nodes": "cfg_node",
        "column_mappings": "cfg_column_mapping",
        "load_strategies": "cfg_load_strategy",
        "quality_rules": "cfg_quality_rule",
        "dependencies": "cfg_dependency",
        "runtime_parameters": "cfg_runtime_parameter",
    }

    def __init__(
        self,
        catalog: Any | None = None,
        spark: Any | None = None,
        table_overrides: Mapping[str, str] | None = None,
    ) -> None:
        self.catalog = catalog
        self.spark = spark
        self.table_names = {**self.table_names, **(table_overrides or {})}

    def load(self, active_only: bool = True) -> MetadataBundle:
        """Load all supported metadata tables and return a validated bundle."""
        pipelines = self._load_pipelines(active_only)
        datasets = self._load_datasets(active_only)
        nodes = self._load_nodes(active_only)
        column_mappings = self._load_column_mappings(active_only)
        load_strategies = self._load_load_strategies()
        quality_rules = self._load_quality_rules(active_only)

        bundle = MetadataBundle(
            pipelines={pipeline.pipeline_id: pipeline for pipeline in pipelines},
            datasets={dataset.dataset_id: dataset for dataset in datasets},
            nodes=nodes,
            column_mappings=column_mappings,
            load_strategies={
                (strategy.pipeline_id, strategy.target_dataset_id): strategy
                for strategy in load_strategies
            },
            quality_rules=quality_rules,
            dependencies=self._read_records("dependencies", required=False),
            runtime_parameters=self._read_records("runtime_parameters", required=False),
        )
        self.validate(bundle)
        return bundle

    def validate(self, bundle: MetadataBundle) -> None:
        """Validate cross-table references that the factory depends on."""
        errors: list[str] = []

        for node in bundle.nodes:
            if node.pipeline_id not in bundle.pipelines:
                errors.append(f"Node {node.node_id} references unknown pipeline {node.pipeline_id}")
            if node.input_dataset_id and node.input_dataset_id not in bundle.datasets:
                errors.append(
                    f"Node {node.node_id} references unknown input dataset "
                    f"{node.input_dataset_id}"
                )
            if node.output_dataset_id and node.output_dataset_id not in bundle.datasets:
                errors.append(
                    f"Node {node.node_id} references unknown output dataset "
                    f"{node.output_dataset_id}"
                )

        for mapping in bundle.column_mappings:
            if mapping.pipeline_id not in bundle.pipelines:
                errors.append(
                    f"Mapping {mapping.mapping_id} references unknown pipeline "
                    f"{mapping.pipeline_id}"
                )
            if mapping.source_dataset_id not in bundle.datasets:
                errors.append(
                    f"Mapping {mapping.mapping_id} references unknown source dataset "
                    f"{mapping.source_dataset_id}"
                )
            if mapping.target_dataset_id not in bundle.datasets:
                errors.append(
                    f"Mapping {mapping.mapping_id} references unknown target dataset "
                    f"{mapping.target_dataset_id}"
                )

        for (_pipeline_id, target_dataset_id), strategy in bundle.load_strategies.items():
            if strategy.pipeline_id not in bundle.pipelines:
                errors.append(
                    f"Load strategy {strategy.strategy_id} references unknown pipeline "
                    f"{strategy.pipeline_id}"
                )
            if target_dataset_id not in bundle.datasets:
                errors.append(
                    f"Load strategy {strategy.strategy_id} references unknown target dataset "
                    f"{target_dataset_id}"
                )

        if errors:
            raise MetadataValidationError("; ".join(errors))

    def _load_pipelines(self, active_only: bool) -> list[PipelineSpec]:
        records = [self._normalize_common(record) for record in self._read_records("pipelines")]
        if active_only:
            records = [record for record in records if record["is_active"]]
        return [dataclass_from_record(PipelineSpec, record) for record in records]

    def _load_datasets(self, active_only: bool) -> list[DatasetSpec]:
        records = []
        for record in self._read_records("datasets"):
            normalized = self._normalize_common(record)
            normalized["partition_columns"] = parse_string_list(record.get("partition_columns"))
            normalized["primary_key"] = parse_string_list(record.get("primary_key"))
            normalized["full_table_name"] = normalized.get("full_table_name") or ".".join(
                [
                    str(normalized["catalog_name"]),
                    str(normalized["schema_name"]),
                    str(normalized["table_name"]),
                ]
            )
            records.append(normalized)

        if active_only:
            records = [record for record in records if record["is_active"]]
        return [dataclass_from_record(DatasetSpec, record) for record in records]

    def _load_nodes(self, active_only: bool) -> list[NodeSpec]:
        records = []
        for record in self._read_records("nodes"):
            normalized = self._normalize_common(record)
            normalized["execution_order"] = int(record["execution_order"])
            normalized["parameters"] = parse_json_object(record.get("parameters_json"))
            records.append(normalized)

        if active_only:
            records = [record for record in records if record["is_active"]]
        return [dataclass_from_record(NodeSpec, record) for record in records]

    def _load_column_mappings(self, active_only: bool) -> list[ColumnMappingSpec]:
        records = []
        for record in self._read_records("column_mappings", required=False):
            normalized = self._normalize_common(record)
            normalized["is_nullable"] = (
                None
                if record.get("is_nullable") is None
                else parse_bool(record.get("is_nullable"), default=True)
            )
            normalized["is_primary_key"] = parse_bool(record.get("is_primary_key"))
            normalized["is_partition_column"] = parse_bool(record.get("is_partition_column"))
            records.append(normalized)

        if active_only:
            records = [record for record in records if record["is_active"]]
        return [dataclass_from_record(ColumnMappingSpec, record) for record in records]

    def _load_load_strategies(self) -> list[LoadStrategySpec]:
        records = []
        for record in self._read_records("load_strategies", required=False):
            normalized = self._normalize_common(record)
            normalized["merge_keys"] = parse_string_list(record.get("merge_keys"))
            normalized["delete_not_matched"] = parse_bool(record.get("delete_not_matched"))
            normalized["deduplication_keys"] = parse_string_list(record.get("deduplication_keys"))
            normalized["optimize_after_write"] = parse_bool(record.get("optimize_after_write"))
            normalized["zorder_columns"] = parse_string_list(record.get("zorder_columns"))
            if record.get("vacuum_retention_hours") is not None:
                normalized["vacuum_retention_hours"] = int(record["vacuum_retention_hours"])
            records.append(normalized)
        return [dataclass_from_record(LoadStrategySpec, record) for record in records]

    def _load_quality_rules(self, active_only: bool) -> list[QualityRuleSpec]:
        records = []
        for record in self._read_records("quality_rules", required=False):
            normalized = self._normalize_common(record)
            normalized["threshold"] = float(record.get("threshold") or 0.0)
            records.append(normalized)

        if active_only:
            records = [record for record in records if record["is_active"]]
        return [dataclass_from_record(QualityRuleSpec, record) for record in records]

    def _normalize_common(self, record: MetadataRecord) -> MetadataRecord:
        normalized = dict(record)
        normalized["is_active"] = parse_bool(record.get("is_active"), default=True)
        return normalized

    def _read_records(self, table_key: str, required: bool = True) -> list[MetadataRecord]:
        table_name = self.table_names[table_key]
        try:
            if self.catalog is not None:
                return rows_to_records(self.catalog.load(table_name))
            if self.spark is not None:
                return rows_to_records(self.spark.table(table_name))
        except Exception:
            if required:
                raise
            return []

        if required:
            raise RuntimeError("ConfigLoader requires either a Kedro catalog or a SparkSession")
        return []
