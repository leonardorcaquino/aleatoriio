"""Build Kedro nodes dynamically from cfg_node metadata."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from kedro.pipeline import node
from pyspark.sql import functions as F

from .dataset_resolver import DatasetResolver
from .load_strategies import create_load_strategy
from .models import ColumnMappingSpec, MetadataBundle, NodeSpec
from .quality.rule_runner import QualityRuleRunner


NodeFunction = Callable[..., Any]


class NodeBuilder:
    """Create executable Kedro nodes from metadata."""

    def __init__(
        self,
        spark: Any,
        bundle: MetadataBundle,
        write_options: dict[str, Any] | None = None,
        custom_functions: dict[str, NodeFunction] | None = None,
    ) -> None:
        self.spark = spark
        self.bundle = bundle
        self.resolver = DatasetResolver(spark)
        self.write_options = write_options or {}
        self.custom_functions = custom_functions or {}

    def build(
        self,
        node_spec: NodeSpec,
        upstream_output: str | None = None,
    ) -> tuple[Any, str | None]:
        """Build one Kedro node and return it with its output name."""
        if node_spec.node_type == "extract":
            output_name = self._data_output_name(node_spec)
            return (
                node(
                    func=self._extract_function(node_spec),
                    inputs=None,
                    outputs=output_name,
                    name=node_spec.node_name,
                    tags=[node_spec.pipeline_id, node_spec.node_type],
                ),
                output_name,
            )

        if node_spec.node_type == "load":
            if upstream_output is None:
                raise ValueError(f"Load node {node_spec.node_id} requires an upstream DataFrame")
            metrics_output = f"{node_spec.pipeline_id}.{node_spec.node_id}.metrics"
            return (
                node(
                    func=self._load_function(node_spec),
                    inputs=upstream_output,
                    outputs=metrics_output,
                    name=node_spec.node_name,
                    tags=[node_spec.pipeline_id, node_spec.node_type],
                ),
                None,
            )

        if upstream_output is None:
            raise ValueError(f"Node {node_spec.node_id} requires an upstream DataFrame")

        output_name = self._data_output_name(node_spec)
        return (
            node(
                func=self._dataframe_function(node_spec),
                inputs=upstream_output,
                outputs=output_name,
                name=node_spec.node_name,
                tags=[node_spec.pipeline_id, node_spec.node_type],
            ),
            output_name,
        )

    def _extract_function(self, node_spec: NodeSpec) -> NodeFunction:
        def extract() -> Any:
            dataset_id = node_spec.input_dataset_id or node_spec.output_dataset_id
            if dataset_id is None:
                raise ValueError(f"Extract node {node_spec.node_id} requires a dataset id")
            dataset = self.bundle.datasets[dataset_id]
            return self.resolver.read(dataset, where=node_spec.parameters.get("where"))

        return self.custom_functions.get(node_spec.function_name, extract)

    def _dataframe_function(self, node_spec: NodeSpec) -> NodeFunction:
        if node_spec.function_name in self.custom_functions:
            return self.custom_functions[node_spec.function_name]

        if node_spec.node_type == "transform":
            return self._transform_function(node_spec)
        if node_spec.node_type == "validate":
            return self._validate_function(node_spec)
        raise ValueError(f"Unsupported dataframe node_type: {node_spec.node_type}")

    def _transform_function(self, node_spec: NodeSpec) -> NodeFunction:
        def transform(dataframe: Any) -> Any:
            filtered = self._apply_where(dataframe, node_spec.parameters.get("where"))
            mapped = self._apply_column_mappings(filtered, node_spec)
            deduplicated = self._apply_deduplication(mapped, node_spec.parameters)
            return self._apply_technical_columns(deduplicated, node_spec)

        return transform

    def _validate_function(self, node_spec: NodeSpec) -> NodeFunction:
        def validate(dataframe: Any) -> Any:
            dataset_id = node_spec.input_dataset_id or node_spec.output_dataset_id
            rules = self.bundle.quality_rules_for(node_spec.pipeline_id, dataset_id)
            validated, _ = QualityRuleRunner().run(dataframe, rules)
            return validated

        return validate

    def _load_function(self, node_spec: NodeSpec) -> NodeFunction:
        def load(dataframe: Any) -> dict[str, int]:
            target_dataset_id = node_spec.output_dataset_id
            if target_dataset_id is None:
                raise ValueError(f"Load node {node_spec.node_id} requires output_dataset_id")
            target_dataset = self.bundle.datasets[target_dataset_id]
            strategy = self.bundle.load_strategy_for(node_spec.pipeline_id, target_dataset_id)
            if strategy is None:
                load_type = target_dataset.write_mode or "append"
                strategy = self._fallback_strategy(node_spec, target_dataset_id, load_type)
            return create_load_strategy(
                strategy.load_type,
                resolver=self.resolver,
                write_options=self.write_options,
            ).execute(dataframe, target_dataset, strategy)

        return self.custom_functions.get(node_spec.function_name, load)

    def _apply_where(self, dataframe: Any, where: str | None) -> Any:
        return dataframe.where(where) if where else dataframe

    def _apply_column_mappings(self, dataframe: Any, node_spec: NodeSpec) -> Any:
        mappings = self._mappings_for_node(node_spec)
        if not mappings:
            return dataframe

        expressions = []
        source_columns = set(dataframe.columns)
        for mapping in mappings:
            if mapping.transformation_expr:
                column = F.expr(mapping.transformation_expr)
            elif mapping.source_column in source_columns:
                column = F.col(mapping.source_column)
            elif mapping.default_value is not None:
                column = F.lit(mapping.default_value)
            else:
                column = F.lit(None)

            if mapping.target_type:
                column = column.cast(mapping.target_type)
            expressions.append(column.alias(mapping.target_column))
        return dataframe.select(*expressions)

    def _apply_deduplication(self, dataframe: Any, parameters: dict[str, Any]) -> Any:
        keys = parameters.get("deduplication_keys") or parameters.get("drop_duplicates")
        if keys is True:
            return dataframe.dropDuplicates()
        if isinstance(keys, str):
            keys = [item.strip() for item in keys.split(",") if item.strip()]
        if keys:
            return dataframe.dropDuplicates(keys)
        return dataframe

    def _apply_technical_columns(self, dataframe: Any, node_spec: NodeSpec) -> Any:
        if not node_spec.parameters.get("add_technical_columns", True):
            return dataframe
        return (
            dataframe.withColumn("_processing_timestamp", F.current_timestamp())
            .withColumn("_pipeline_id", F.lit(node_spec.pipeline_id))
            .withColumn("_node_id", F.lit(node_spec.node_id))
        )

    def _mappings_for_node(self, node_spec: NodeSpec) -> list[ColumnMappingSpec]:
        mappings = self.bundle.mappings_for_pipeline(node_spec.pipeline_id)
        if node_spec.input_dataset_id:
            mappings = [
                mapping
                for mapping in mappings
                if mapping.source_dataset_id == node_spec.input_dataset_id
            ]
        if node_spec.output_dataset_id:
            mappings = [
                mapping
                for mapping in mappings
                if mapping.target_dataset_id == node_spec.output_dataset_id
            ]
        return mappings

    def _fallback_strategy(
        self,
        node_spec: NodeSpec,
        target_dataset_id: str,
        load_type: str,
    ) -> Any:
        from .models import LoadStrategySpec

        return LoadStrategySpec(
            strategy_id=f"{node_spec.node_id}_fallback",
            pipeline_id=node_spec.pipeline_id,
            target_dataset_id=target_dataset_id,
            load_type=load_type,
        )

    def _data_output_name(self, node_spec: NodeSpec) -> str:
        return f"{node_spec.pipeline_id}.{node_spec.node_id}.data"
