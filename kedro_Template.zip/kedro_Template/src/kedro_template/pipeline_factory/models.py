"""Metadata contracts used by the dynamic pipeline factory."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any


MetadataRecord = dict[str, Any]


@dataclass(frozen=True)
class DatasetSpec:
    """Logical dataset described by cfg_dataset."""

    dataset_id: str
    dataset_name: str
    catalog_name: str
    schema_name: str
    table_name: str
    full_table_name: str
    format: str = "delta"
    layer: str | None = None
    read_mode: str = "table"
    write_mode: str | None = None
    storage_path: str | None = None
    partition_columns: list[str] = field(default_factory=list)
    primary_key: list[str] = field(default_factory=list)
    watermark_column: str | None = None
    is_active: bool = True
    description: str | None = None


@dataclass(frozen=True)
class PipelineSpec:
    """Logical pipeline described by cfg_pipeline."""

    pipeline_id: str
    pipeline_name: str
    domain: str
    pipeline_type: str
    layer_from: str | None = None
    layer_to: str | None = None
    is_active: bool = True
    schedule_cron: str | None = None
    owner_team: str | None = None
    criticality: str | None = None
    description: str | None = None


@dataclass(frozen=True)
class NodeSpec:
    """Kedro node metadata described by cfg_node."""

    node_id: str
    pipeline_id: str
    node_name: str
    node_type: str
    function_name: str
    execution_order: int
    input_dataset_id: str | None = None
    output_dataset_id: str | None = None
    is_active: bool = True
    parameters: dict[str, Any] = field(default_factory=dict)
    description: str | None = None


@dataclass(frozen=True)
class ColumnMappingSpec:
    """Column-level mapping described by cfg_column_mapping."""

    mapping_id: str
    pipeline_id: str
    source_dataset_id: str
    target_dataset_id: str
    source_column: str
    target_column: str
    target_type: str | None = None
    is_nullable: bool | None = None
    default_value: Any | None = None
    transformation_expr: str | None = None
    is_primary_key: bool = False
    is_partition_column: bool = False
    is_active: bool = True


@dataclass(frozen=True)
class LoadStrategySpec:
    """Write strategy described by cfg_load_strategy."""

    strategy_id: str
    pipeline_id: str
    target_dataset_id: str
    load_type: str
    merge_keys: list[str] = field(default_factory=list)
    watermark_column: str | None = None
    watermark_value_source: str | None = None
    delete_not_matched: bool = False
    deduplication_keys: list[str] = field(default_factory=list)
    deduplication_order: str | None = None
    optimize_after_write: bool = False
    zorder_columns: list[str] = field(default_factory=list)
    vacuum_retention_hours: int | None = None


@dataclass(frozen=True)
class QualityRuleSpec:
    """Data quality rule described by cfg_quality_rule."""

    rule_id: str
    pipeline_id: str
    dataset_id: str
    rule_type: str
    column_name: str | None = None
    rule_expression: str | None = None
    severity: str = "error"
    threshold: float = 0.0
    on_failure: str = "fail_pipeline"
    is_active: bool = True


@dataclass(frozen=True)
class AuditEvent:
    """Execution event written to cfg_audit_log."""

    execution_id: str
    pipeline_id: str
    status: str
    started_at: datetime
    node_id: str | None = None
    finished_at: datetime | None = None
    source_count: int | None = None
    target_count: int | None = None
    rejected_count: int | None = None
    watermark_start: str | None = None
    watermark_end: str | None = None
    error_message: str | None = None
    databricks_job_id: str | None = None
    databricks_run_id: str | None = None


@dataclass
class MetadataBundle:
    """Loaded metadata, indexed for factory usage."""

    pipelines: dict[str, PipelineSpec]
    datasets: dict[str, DatasetSpec]
    nodes: list[NodeSpec]
    column_mappings: list[ColumnMappingSpec] = field(default_factory=list)
    load_strategies: dict[tuple[str, str], LoadStrategySpec] = field(default_factory=dict)
    quality_rules: list[QualityRuleSpec] = field(default_factory=list)
    dependencies: list[MetadataRecord] = field(default_factory=list)
    runtime_parameters: list[MetadataRecord] = field(default_factory=list)

    def nodes_for_pipeline(self, pipeline_id: str) -> list[NodeSpec]:
        """Return active nodes in execution order for a pipeline."""
        return sorted(
            [node for node in self.nodes if node.pipeline_id == pipeline_id and node.is_active],
            key=lambda node: node.execution_order,
        )

    def mappings_for_pipeline(self, pipeline_id: str) -> list[ColumnMappingSpec]:
        """Return active column mappings for a pipeline."""
        return [
            mapping
            for mapping in self.column_mappings
            if mapping.pipeline_id == pipeline_id and mapping.is_active
        ]

    def quality_rules_for(
        self,
        pipeline_id: str,
        dataset_id: str | None = None,
    ) -> list[QualityRuleSpec]:
        """Return active quality rules, optionally filtered by dataset."""
        return [
            rule
            for rule in self.quality_rules
            if rule.pipeline_id == pipeline_id
            and rule.is_active
            and (dataset_id is None or rule.dataset_id == dataset_id)
        ]

    def load_strategy_for(
        self, pipeline_id: str, target_dataset_id: str | None
    ) -> LoadStrategySpec | None:
        """Return the load strategy configured for a pipeline and target dataset."""
        if target_dataset_id is None:
            return None
        return self.load_strategies.get((pipeline_id, target_dataset_id))
