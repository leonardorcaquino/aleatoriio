"""Base contracts for load strategies."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from ..dataset_resolver import DatasetResolver
from ..models import DatasetSpec, LoadStrategySpec


class LoadStrategy(ABC):
    """Base class for all Spark/Delta load strategies."""

    load_type: str

    def __init__(
        self,
        resolver: DatasetResolver,
        write_options: dict[str, Any] | None = None,
    ) -> None:
        self.resolver = resolver
        self.write_options = write_options or {}

    @abstractmethod
    def execute(
        self,
        dataframe: Any,
        target_dataset: DatasetSpec,
        strategy: LoadStrategySpec,
    ) -> dict[str, int]:
        """Write a DataFrame and return execution metrics."""

    def _post_write(self, target_dataset: DatasetSpec, strategy: LoadStrategySpec) -> None:
        if strategy.optimize_after_write:
            self.resolver.optimize(target_dataset, strategy.zorder_columns)
        if strategy.vacuum_retention_hours is not None:
            self.resolver.vacuum(target_dataset, strategy.vacuum_retention_hours)
