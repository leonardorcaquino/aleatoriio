"""Incremental append load strategy."""

from __future__ import annotations

from typing import Any

from .base import LoadStrategy
from ..models import DatasetSpec, LoadStrategySpec


class IncrementalAppendStrategy(LoadStrategy):
    """Append new rows to the target table."""

    load_type = "incremental_append"

    def execute(
        self,
        dataframe: Any,
        target_dataset: DatasetSpec,
        strategy: LoadStrategySpec,
    ) -> dict[str, int]:
        count = dataframe.count()
        self.resolver.write_append(dataframe, target_dataset, self.write_options)
        self._post_write(target_dataset, strategy)
        return {"source_count": count, "target_count": count, "rejected_count": 0}
