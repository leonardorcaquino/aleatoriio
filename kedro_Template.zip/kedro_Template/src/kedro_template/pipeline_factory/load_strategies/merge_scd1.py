"""SCD1 merge load strategy."""

from __future__ import annotations

from typing import Any

from delta.tables import DeltaTable

from .base import LoadStrategy
from ..models import DatasetSpec, LoadStrategySpec


class MergeScd1Strategy(LoadStrategy):
    """Upsert incoming rows into a Delta table using SCD1 semantics."""

    load_type = "merge_scd1"

    def execute(
        self,
        dataframe: Any,
        target_dataset: DatasetSpec,
        strategy: LoadStrategySpec,
    ) -> dict[str, int]:
        if not strategy.merge_keys:
            raise ValueError("merge_scd1 requires merge_keys")

        count = dataframe.count()
        if not self._target_exists(target_dataset):
            self.resolver.write_overwrite(dataframe, target_dataset, self.write_options)
            self._post_write(target_dataset, strategy)
            return {"source_count": count, "target_count": count, "rejected_count": 0}

        target = DeltaTable.forName(self.resolver.spark, target_dataset.full_table_name)
        condition = " AND ".join([f"target.{key} = source.{key}" for key in strategy.merge_keys])
        merge_builder = (
            target.alias("target")
            .merge(dataframe.alias("source"), condition)
            .whenMatchedUpdateAll()
            .whenNotMatchedInsertAll()
        )
        if strategy.delete_not_matched:
            merge_builder = merge_builder.whenNotMatchedBySourceDelete()
        merge_builder.execute()

        self._post_write(target_dataset, strategy)
        return {"source_count": count, "target_count": count, "rejected_count": 0}

    def _target_exists(self, target_dataset: DatasetSpec) -> bool:
        try:
            return bool(self.resolver.spark.catalog.tableExists(target_dataset.full_table_name))
        except Exception:
            return True
