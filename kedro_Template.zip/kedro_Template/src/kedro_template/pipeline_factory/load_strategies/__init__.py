"""Load strategy implementations."""

from __future__ import annotations

from typing import Any

from .base import LoadStrategy
from .full_overwrite import FullOverwriteStrategy
from .incremental_append import IncrementalAppendStrategy
from .merge_scd1 import MergeScd1Strategy


def create_load_strategy(
    load_type: str,
    resolver: Any,
    write_options: dict[str, Any] | None = None,
) -> LoadStrategy:
    """Create a load strategy by metadata load_type."""
    registry: dict[str, type[LoadStrategy]] = {
        "full": FullOverwriteStrategy,
        "full_overwrite": FullOverwriteStrategy,
        "overwrite": FullOverwriteStrategy,
        "append": IncrementalAppendStrategy,
        "incremental_append": IncrementalAppendStrategy,
        "merge": MergeScd1Strategy,
        "scd1": MergeScd1Strategy,
        "merge_scd1": MergeScd1Strategy,
    }
    try:
        strategy_class = registry[load_type]
    except KeyError as exc:
        raise ValueError(f"Unsupported load_type: {load_type}") from exc
    return strategy_class(resolver=resolver, write_options=write_options)
