from __future__ import annotations

import unittest

from kedro_template.pipeline_factory.metadata_utils import parse_bool, parse_string_list


class MetadataUtilsTest(unittest.TestCase):
    def test_parse_bool_accepts_common_metadata_values(self):
        self.assertIs(parse_bool("sim"), True)
        self.assertIs(parse_bool("false"), False)
        self.assertIs(parse_bool(None, default=True), True)

    def test_parse_string_list_accepts_json_and_csv(self):
        self.assertEqual(parse_string_list('["a", "b"]'), ["a", "b"])
        self.assertEqual(parse_string_list("a,b"), ["a", "b"])
        self.assertEqual(parse_string_list(None), [])


if __name__ == "__main__":
    unittest.main()
