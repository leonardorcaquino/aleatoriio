from __future__ import annotations

import unittest

from kedro_template.pipeline_factory.config_loader import ConfigLoader, MetadataValidationError


class FakeCatalog:
    def __init__(self, tables):
        self.tables = tables

    def load(self, name):
        if name not in self.tables:
            raise KeyError(name)
        return self.tables[name]


def base_tables():
    return {
        "cfg_pipeline": [
            {
                "pipeline_id": "pipe_customer",
                "pipeline_name": "customer_bronze_to_silver",
                "domain": "customer",
                "pipeline_type": "transformacao",
                "is_active": "true",
            }
        ],
        "cfg_dataset": [
            {
                "dataset_id": "ds_customer_bronze",
                "dataset_name": "customer_bronze",
                "catalog_name": "main",
                "schema_name": "bronze",
                "table_name": "customer",
                "full_table_name": "",
                "format": "delta",
                "layer": "bronze",
                "read_mode": "table",
                "partition_columns": "dt_ref,country",
                "primary_key": '["customer_id"]',
                "is_active": True,
            },
            {
                "dataset_id": "ds_customer_silver",
                "dataset_name": "customer_silver",
                "catalog_name": "main",
                "schema_name": "silver",
                "table_name": "customer",
                "full_table_name": "main.silver.customer",
                "format": "delta",
                "layer": "silver",
                "read_mode": "table",
                "write_mode": "merge_scd1",
                "is_active": True,
            },
        ],
        "cfg_node": [
            {
                "node_id": "extract_customer",
                "pipeline_id": "pipe_customer",
                "node_name": "extract_customer",
                "node_type": "extract",
                "input_dataset_id": "ds_customer_bronze",
                "function_name": "generic_extract",
                "execution_order": "10",
                "is_active": True,
                "parameters_json": '{"where": "dt_ref >= current_date()"}',
            },
            {
                "node_id": "load_customer",
                "pipeline_id": "pipe_customer",
                "node_name": "load_customer",
                "node_type": "load",
                "output_dataset_id": "ds_customer_silver",
                "function_name": "generic_load",
                "execution_order": 20,
                "is_active": True,
            },
        ],
        "cfg_column_mapping": [],
        "cfg_load_strategy": [
            {
                "strategy_id": "st_customer",
                "pipeline_id": "pipe_customer",
                "target_dataset_id": "ds_customer_silver",
                "load_type": "merge_scd1",
                "merge_keys": "customer_id",
            }
        ],
        "cfg_quality_rule": [],
    }


class ConfigLoaderTest(unittest.TestCase):
    def test_normalizes_metadata(self):
        bundle = ConfigLoader(catalog=FakeCatalog(base_tables())).load()

        self.assertEqual(list(bundle.pipelines), ["pipe_customer"])
        self.assertEqual(
            bundle.datasets["ds_customer_bronze"].full_table_name,
            "main.bronze.customer",
        )
        self.assertEqual(
            bundle.datasets["ds_customer_bronze"].partition_columns,
            ["dt_ref", "country"],
        )
        self.assertEqual(bundle.datasets["ds_customer_bronze"].primary_key, ["customer_id"])
        self.assertEqual(
            bundle.nodes_for_pipeline("pipe_customer")[0].parameters["where"],
            "dt_ref >= current_date()",
        )
        self.assertEqual(
            bundle.load_strategy_for("pipe_customer", "ds_customer_silver").merge_keys,
            ["customer_id"],
        )

    def test_validates_unknown_dataset_reference(self):
        tables = base_tables()
        tables["cfg_node"][0]["input_dataset_id"] = "missing_dataset"

        with self.assertRaises(MetadataValidationError):
            ConfigLoader(catalog=FakeCatalog(tables)).load()


if __name__ == "__main__":
    unittest.main()
