﻿# Kedro Template - Databricks Pipeline Factory

Estrutura base para uma arquitetura de pipeline factory usando Kedro, Databricks, Delta Lake, ADLS e Unity Catalog.

A proposta e separar configuracao, montagem dinamica de pipelines, estrategias de carga, regras de qualidade e auditoria operacional.

## Objetivo

- Ler metadados de tabelas Delta parametrizadas.
- Montar pipelines e nodes Kedro dinamicamente.
- Executar transformacoes em Databricks usando Spark.
- Gravar dados finais em tabelas Delta governadas pelo Unity Catalog.
- Registrar auditoria, metricas, watermark e status de execucao.

## Versoes base

- Python >= 3.11
- Kedro >= 1.3.0
- kedro-datasets >= 3.0.0
- PySpark >= 3.5.0
- Delta Spark >= 3.0.0

## Estrutura

```text
conf/
  base/
    catalog/
    parameters/
    logging/
docs/
  architecture/
  metadata_tables/
src/kedro_template/
  pipeline_factory/
    load_strategies/
    quality/
  pipelines/
tests/
  pipeline_factory/
```

## Status

Este projeto contem apenas a estrutura inicial e documentos de desenho. A implementacao dos componentes Kedro/Spark deve ser adicionada em uma proxima etapa.
