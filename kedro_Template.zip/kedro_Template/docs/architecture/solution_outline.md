﻿# Esboco da Solucao

## Visao geral

A solucao usa Kedro como camada de orquestracao logica e Databricks como runtime Spark. As fontes e destinos sao tabelas Delta em ADLS governadas pelo Unity Catalog.

As pipelines sao descritas por tabelas Delta de metadados. Em tempo de execucao, o Kedro le essas configuracoes, resolve datasets, monta nodes dinamicos e executa as estrategias de carga configuradas.

## Componentes

- Metadata Delta Tables: configuram pipelines, datasets, nodes, mapeamentos, estrategias de carga e qualidade.
- Config Loader: carrega e valida metadados.
- Pipeline Builder: monta objetos Pipeline do Kedro.
- Node Builder: traduz cada registro de cfg_node em um node Kedro.
- Dataset Resolver: resolve catalog.schema.table ou paths ADLS.
- Quality Runner: executa regras configuradas.
- Load Strategies: implementa append, overwrite, merge SCD1 e futuramente SCD2.
- Audit Logger: registra status, contagens, erros, watermark e run IDs.

## Fluxo

1. Databricks Job inicia `kedro run` com parametros de ambiente e pipeline.
2. Kedro carrega tabelas de configuracao no Unity Catalog.
3. Factory filtra pipelines e nodes ativos.
4. Factory monta DAG Kedro dinamica.
5. Nodes leem origem Delta, aplicam mapeamentos, validam qualidade e gravam destino.
6. Auditoria registra o resultado da execucao.

## Principio de desenho

As tabelas de configuracao parametrizam padroes conhecidos. Transformacoes muito especificas devem apontar para funcoes Python/Spark registradas no projeto, evitando transformar metadados em uma linguagem complexa escondida.
