﻿# Especificacao Inicial das Tabelas de Metadados

## cfg_pipeline

| Campo | Tipo | Obrigatorio | Descricao |
|---|---|---:|---|
| pipeline_id | string | sim | Identificador unico |
| pipeline_name | string | sim | Nome funcional |
| domain | string | sim | Dominio de negocio |
| layer_from | string | nao | Camada origem |
| layer_to | string | nao | Camada destino |
| pipeline_type | string | sim | ingestao, transformacao, consolidacao, quality_check |
| is_active | boolean | sim | Indica se esta ativo |
| schedule_cron | string | nao | Agendamento esperado |
| owner_team | string | nao | Time responsavel |
| criticality | string | nao | baixa, media, alta, critica |
| description | string | nao | Descricao |
| created_at | timestamp | sim | Criacao |
| updated_at | timestamp | sim | Atualizacao |

## cfg_dataset

| Campo | Tipo | Obrigatorio | Descricao |
|---|---|---:|---|
| dataset_id | string | sim | Identificador unico |
| dataset_name | string | sim | Nome logico |
| catalog_name | string | sim | Catalogo Unity Catalog |
| schema_name | string | sim | Schema/database |
| table_name | string | sim | Tabela |
| full_table_name | string | sim | catalog.schema.table |
| storage_path | string | nao | Path ADLS quando necessario |
| format | string | sim | delta, parquet, csv |
| layer | string | sim | bronze, silver, gold, metadata |
| read_mode | string | sim | table, path, query |
| write_mode | string | nao | append, overwrite, merge, scd1, scd2 |
| partition_columns | array<string> | nao | Colunas de particao |
| primary_key | array<string> | nao | Chaves naturais |
| watermark_column | string | nao | Coluna incremental |
| is_active | boolean | sim | Indica se esta ativo |
| description | string | nao | Descricao |

## cfg_node

| Campo | Tipo | Obrigatorio | Descricao |
|---|---|---:|---|
| node_id | string | sim | Identificador unico |
| pipeline_id | string | sim | Pipeline relacionado |
| node_name | string | sim | Nome do node Kedro |
| node_type | string | sim | extract, transform, validate, load |
| input_dataset_id | string | nao | Dataset de entrada |
| output_dataset_id | string | nao | Dataset de saida |
| function_name | string | sim | Funcao executora |
| execution_order | int | sim | Ordem no pipeline |
| is_active | boolean | sim | Indica se esta ativo |
| parameters_json | string | nao | Parametros especificos em JSON |
| description | string | nao | Descricao |

## cfg_column_mapping

| Campo | Tipo | Obrigatorio | Descricao |
|---|---|---:|---|
| mapping_id | string | sim | Identificador unico |
| pipeline_id | string | sim | Pipeline relacionado |
| source_dataset_id | string | sim | Dataset origem |
| target_dataset_id | string | sim | Dataset destino |
| source_column | string | sim | Coluna origem |
| target_column | string | sim | Coluna destino |
| target_type | string | nao | Tipo destino |
| is_nullable | boolean | nao | Aceita nulo |
| default_value | string | nao | Valor padrao |
| transformation_expr | string | nao | Expressao SQL/Spark simples |
| is_primary_key | boolean | nao | Compoe chave |
| is_partition_column | boolean | nao | Compoe particao |
| is_active | boolean | sim | Indica se esta ativo |

## cfg_load_strategy

| Campo | Tipo | Obrigatorio | Descricao |
|---|---|---:|---|
| strategy_id | string | sim | Identificador unico |
| pipeline_id | string | sim | Pipeline relacionado |
| target_dataset_id | string | sim | Dataset destino |
| load_type | string | sim | full, append, incremental_append, merge_scd1, merge_scd2 |
| merge_keys | array<string> | nao | Chaves de merge |
| watermark_column | string | nao | Coluna incremental |
| watermark_value_source | string | nao | audit, max_target, parameter |
| delete_not_matched | boolean | nao | Remove ausentes no merge |
| deduplication_keys | array<string> | nao | Chaves de deduplicacao |
| deduplication_order | string | nao | Ordenacao de desempate |
| optimize_after_write | boolean | nao | Executa optimize |
| zorder_columns | array<string> | nao | Colunas Z-ORDER |
| vacuum_retention_hours | int | nao | Retencao vacuum |

## cfg_audit_log

| Campo | Tipo | Obrigatorio | Descricao |
|---|---|---:|---|
| execution_id | string | sim | Identificador da execucao |
| pipeline_id | string | sim | Pipeline executado |
| node_id | string | nao | Node executado |
| status | string | sim | running, success, failed, skipped |
| started_at | timestamp | sim | Inicio |
| finished_at | timestamp | nao | Fim |
| source_count | long | nao | Registros lidos |
| target_count | long | nao | Registros gravados |
| rejected_count | long | nao | Registros rejeitados |
| watermark_start | string | nao | Watermark inicial |
| watermark_end | string | nao | Watermark final |
| error_message | string | nao | Erro |
| databricks_job_id | string | nao | Job ID |
| databricks_run_id | string | nao | Run ID |
