﻿# Metadata-Driven Processing Engine.

**Language:** English (US) | [Portuguese (Brazil)](README.md)

![Status](https://img.shields.io/badge/status-enterprise%20template-EC0000?style=flat-square)
![Runtime](https://img.shields.io/badge/runtime-Databricks-EC0000?style=flat-square)
![Framework](https://img.shields.io/badge/framework-Kedro-1F1F1F?style=flat-square)
![Storage](https://img.shields.io/badge/storage-ADLS-6B7280?style=flat-square)

Enterprise template for generating Kedro artifacts from metadata, running the
resulting pipeline on Databricks, and publishing immutable execution snapshots
to ADLS for auditability, troubleshooting, and replay.

This project is designed for environments where data pipelines must be driven
by metadata, while still producing explicit, inspectable, and auditable Kedro
artifacts such as `catalog.yml`, `parameters.yml`, `node.yaml`, and `pipeline.yaml`.

## Table of Contents

- [Purpose](#purpose)
- [Architecture Thesis](#architecture-thesis)
- [Visual Guidelines](#visual-guidelines)
- [Solution Diagrams](#solution-diagrams)
- [Base Versions](#base-versions)
- [Enterprise Flow](#enterprise-flow)
- [Project Structure](#project-structure)
- [Core Components](#core-components)
- [Metadata Model](#metadata-model)
- [Collection Update Flow](#collection-update-flow)
- [Generated Artifacts](#generated-artifacts)
- [ADLS Snapshot Publishing](#adls-snapshot-publishing)
- [Databricks Mount Point](#databricks-mount-point)
- [Snapshot Retention](#snapshot-retention)
- [Troubleshooting and Auditability](#troubleshooting-and-auditability)
- [Running Locally](#running-locally)
- [Running on Databricks](#running-on-databricks)
- [How Kedro Runs the Generated Pipeline](#how-kedro-runs-the-generated-pipeline)
- [Architectural Decisions](#architectural-decisions)
- [Risks and Mitigations](#risks-and-mitigations)
- [Recommended Next Steps](#recommended-next-steps)

## Purpose

The purpose of this template is to materialize Kedro pipelines from metadata.

Instead of manually creating all Kedro files for each pipeline, the solution
reads metadata documents and generates:

- `conf/base/catalog.yml`
- `conf/base/parameters.yml`
- `conf/base/node.yaml`
- `conf/base/pipeline.yaml`
- metadata snapshots
- `manifest.yml`
- `checksums.json`

Kedro then runs concrete, visible, and traceable artifacts.

This approach avoids a fully in-memory dynamic pipeline that is hard to audit.
It combines metadata-driven flexibility with an execution model that is easier
to govern in an enterprise environment.

## Architecture Thesis

The core thesis is:

```text
Metadata defines intent.
Materialized artifacts define execution.
Snapshots guarantee auditability and replay.
Kedro executes an explicit contract.
```

Responsibility split:

```text
MongoDB or JSON files
  Operational and editable metadata layer

Artifact Generator
  Materializes Kedro catalog, parameters, node definitions, and pipeline definitions

ADLS
  Stores the immutable snapshot of what was generated and executed

Kedro
  Runs the pipeline using materialized artifacts

Databricks
  Spark runtime and job execution environment

Delta Tables
  Data, governance, and searchable audit layer
```

## Visual Guidelines

The README follows a corporate visual style inspired by financial enterprise environments and suitable for architecture reviews.

| Element | Usage |
|---|---|
| Red `#EC0000` | Highlights, primary borders, and critical elements |
| Black `#1F1F1F` | Main text and structural components |
| Gray `#6B7280` | Lines, connectors, and secondary information |
| Light gray `#F7F7F7` | Grouping and support areas |
| White `#FFFFFF` | Main background and clean readability |

Applied principles:

- clean diagrams without logos inside flowcharts;
- logos only in legend tables;
- red used as an accent, not as a dominant fill color;
- high contrast for quick scanning;
- short labels inside nodes for presentation-friendly diagrams.

## Solution Diagrams

The diagrams use a corporate color palette and concise labels. Logos are kept
in the legend table so the flowcharts remain balanced and easy to read.

### Technology Legend

| Technology | Role in the solution |
|---|---|
| <img src="https://cdn.simpleicons.org/mongodb/47A248" width="12" alt="MongoDB"/> MongoDB | Operational and editable metadata source |
| <img src="https://cdn.simpleicons.org/databricks/FF3621" width="12" alt="Databricks"/> Databricks | Job orchestration and execution runtime |
| <img src="https://cdn.simpleicons.org/apachekedro/FFC900" width="12" alt="Kedro"/> Kedro | Pipeline framework and artifact execution layer |
| <img src="https://cdn.simpleicons.org/apachespark/E25A1C" width="12" alt="Apache Spark"/> Apache Spark | Distributed processing engine |
| <img src="https://cdn.simpleicons.org/microsoftazure/0078D4" width="12" alt="Microsoft Azure"/> ADLS / Azure | Official artifact snapshot storage |
| <img src="https://cdn.simpleicons.org/python/3776AB" width="12" alt="Python"/> Python | Generator and node implementation language |
| <img src="https://cdn.simpleicons.org/yaml/CB171E" width="12" alt="YAML"/> YAML | Generated Kedro artifact format |

### Logical Architecture

```mermaid
%%{init: {"theme": "base", "themeVariables": {"background": "#FFFFFF", "primaryColor": "#FFFFFF", "primaryTextColor": "#1F1F1F", "primaryBorderColor": "#EC0000", "lineColor": "#6B7280", "secondaryColor": "#F7F7F7", "tertiaryColor": "#FFF5F5", "fontFamily": "Arial, Helvetica, sans-serif", "clusterBkg": "#FAFAFA", "clusterBorder": "#D1D5DB", "edgeLabelBackground": "#FFFFFF", "actorBkg": "#FFFFFF", "actorBorder": "#EC0000", "actorTextColor": "#1F1F1F", "activationBkgColor": "#FFF1F1", "activationBorderColor": "#EC0000"}}}%%
flowchart LR
    subgraph Metadata["Metadata Layer"]
        MONGO["MongoDB<br/>Editable metadata"]
        JSON["Local JSON<br/>Development and testing"]
    end

    subgraph Generator["Artifact Generator"]
        READER["Metadata Reader"]
        VALIDATOR["Metadata Validator<br/>(next step)"]
        CATALOG["Catalog Generator<br/>catalog.yml"]
        PARAMS["Parameters Generator<br/>parameters.yml"]
        NODEGEN["Nodes Generator<br/>node.yaml"]
        PIPEDEF["Pipeline Definition<br/>pipeline.yaml"]
        SNAPSHOT["Snapshot Publisher<br/>manifest + checksums"]
    end

    subgraph Storage["Storage and Governance"]
        ADLS["ADLS<br/>Official snapshot"]
        SUPPORT["Support area<br/>Redacted snapshot"]
        AUDIT["Delta Audit Table<br/>Searchable index"]
    end

    subgraph Runtime["Execution Runtime"]
        DBX["Databricks Job"]
        KEDRO["Kedro Run"]
        SPARK["Spark"]
        DELTA["Delta Tables<br/>Governed data layer"]
    end

    MONGO --> READER
    JSON --> READER
    READER --> VALIDATOR
    VALIDATOR --> CATALOG
    VALIDATOR --> PARAMS
    VALIDATOR --> NODEGEN
    VALIDATOR --> PIPEDEF
    CATALOG --> SNAPSHOT
    PARAMS --> SNAPSHOT
    NODEGEN --> SNAPSHOT
    PIPEDEF --> SNAPSHOT
    SNAPSHOT --> ADLS
    SNAPSHOT --> SUPPORT
    SNAPSHOT --> AUDIT
    DBX --> KEDRO
    KEDRO --> SPARK
    SPARK --> DELTA
    ADLS --> DBX
    AUDIT --> DBX
```

### Generation, Snapshot, and Execution Flow

```mermaid
%%{init: {"theme": "base", "themeVariables": {"background": "#FFFFFF", "primaryColor": "#FFFFFF", "primaryTextColor": "#1F1F1F", "primaryBorderColor": "#EC0000", "lineColor": "#6B7280", "secondaryColor": "#F7F7F7", "tertiaryColor": "#FFF5F5", "fontFamily": "Arial, Helvetica, sans-serif", "clusterBkg": "#FAFAFA", "clusterBorder": "#D1D5DB", "edgeLabelBackground": "#FFFFFF", "actorBkg": "#FFFFFF", "actorBorder": "#EC0000", "actorTextColor": "#1F1F1F", "activationBkgColor": "#FFF1F1", "activationBorderColor": "#EC0000"}}}%%
sequenceDiagram
    participant Job as Databricks Job
    participant Mongo as MongoDB / JSON
    participant Gen as Artifact Generator
    participant Mount as DBFS Mount
    participant ADLS as ADLS Snapshot
    participant Audit as Delta Audit
    participant Kedro as Kedro Runtime
    participant Delta as Delta Tables

    Job->>Mongo: Read published metadata
    Mongo-->>Gen: Input metadata + output metadata
    Gen->>Gen: Validate metadata
    Gen->>Gen: Generate catalog.yml
    Gen->>Gen: Generate parameters.yml
    Gen->>Gen: Generate node.yaml and pipeline.yaml
    Gen->>Gen: Generate manifest.yml and checksums.json
    Gen->>Mount: Create or reuse mount point
    Mount-->>Gen: dbfs:/mnt/kedro-artifacts
    Gen->>ADLS: Publish execution snapshot
    Gen->>Audit: Register artifact URI and hashes
    Job->>Kedro: Run kedro run --pipeline metadata_engine
    Kedro->>Delta: Read Delta inputs
    Kedro->>Delta: Write Delta output
    Kedro->>Audit: Update status and metrics
```

### Generated Kedro Pipeline

```mermaid
%%{init: {"theme": "base", "themeVariables": {"background": "#FFFFFF", "primaryColor": "#FFFFFF", "primaryTextColor": "#1F1F1F", "primaryBorderColor": "#EC0000", "lineColor": "#6B7280", "secondaryColor": "#F7F7F7", "tertiaryColor": "#FFF5F5", "fontFamily": "Arial, Helvetica, sans-serif", "clusterBkg": "#FAFAFA", "clusterBorder": "#D1D5DB", "edgeLabelBackground": "#FFFFFF", "actorBkg": "#FFFFFF", "actorBorder": "#EC0000", "actorTextColor": "#1F1F1F", "activationBkgColor": "#FFF1F1", "activationBorderColor": "#EC0000"}}}%%
flowchart TD
    ORDERS["input_orders<br/>raw.orders"] --> TORD["transform_orders_node<br/>apply_metadata_transformations"]
    CUSTOMERS["input_customers<br/>raw.customers"] --> TCUS["transform_customers_node<br/>apply_metadata_transformations"]

    PARAM_ORD["params<br/>metadata_engine.input_configs.orders"] --> TORD
    PARAM_CUS["params<br/>metadata_engine.input_configs.customers"] --> TCUS

    TORD --> ORD_TREATED["orders_treated"]
    TCUS --> CUS_TREATED["customers_treated"]

    ORD_TREATED --> BUILD["build_customer_orders_curated_node<br/>build_output_dataframe"]
    CUS_TREATED --> BUILD
    PARAM_OUT["params<br/>metadata_engine.output_config"] --> BUILD

    BUILD --> OUTPUT["output_customer_orders_curated<br/>main.curated.customer_orders"]
```

### Output Assembly Process

```mermaid
%%{init: {"theme": "base", "themeVariables": {"background": "#FFFFFF", "primaryColor": "#FFFFFF", "primaryTextColor": "#1F1F1F", "primaryBorderColor": "#EC0000", "lineColor": "#6B7280", "secondaryColor": "#F7F7F7", "tertiaryColor": "#FFF5F5", "fontFamily": "Arial, Helvetica, sans-serif", "clusterBkg": "#FAFAFA", "clusterBorder": "#D1D5DB", "edgeLabelBackground": "#FFFFFF", "actorBkg": "#FFFFFF", "actorBorder": "#EC0000", "actorTextColor": "#1F1F1F", "activationBkgColor": "#FFF1F1", "activationBorderColor": "#EC0000"}}}%%
flowchart TD
    A["Treated DataFrames"] --> B["Select base input<br/>is_base = true"]
    B --> C["Apply aliases<br/>ord, cus, ..."]
    C --> D["Sort joins by order"]
    D --> E["Build join conditions"]
    E --> F["Execute Spark joins"]
    F --> G["Select final fields"]
    G --> H["Apply final casts"]
    H --> I["Return output DataFrame"]
```

### Execution Snapshot

```mermaid
%%{init: {"theme": "base", "themeVariables": {"background": "#FFFFFF", "primaryColor": "#FFFFFF", "primaryTextColor": "#1F1F1F", "primaryBorderColor": "#EC0000", "lineColor": "#6B7280", "secondaryColor": "#F7F7F7", "tertiaryColor": "#FFF5F5", "fontFamily": "Arial, Helvetica, sans-serif", "clusterBkg": "#FAFAFA", "clusterBorder": "#D1D5DB", "edgeLabelBackground": "#FFFFFF", "actorBkg": "#FFFFFF", "actorBorder": "#EC0000", "actorTextColor": "#1F1F1F", "activationBkgColor": "#FFF1F1", "activationBorderColor": "#EC0000"}}}%%
flowchart LR
    subgraph Local["Local / driver staging"]
        C["catalog.yml"]
        P["parameters.yml"]
        NODEYAML["node.yaml"]
        PIPEYAML["pipeline.yaml"]
        IN["input_metadata_snapshot.json"]
        OUT["output_metadata_snapshot.json"]
        CHK["checksums.json"]
        MAN["manifest.yml"]
    end

    subgraph ADLSPath["ADLS / DBFS Mount"]
        ROOT["dbfs:/mnt/kedro-artifacts"]
        ENV["env=prd"]
        PIPE["pipeline=customer_orders_curated"]
        EXEC["execution_id=..."]
    end

    C --> ROOT
    P --> ROOT
    NODEYAML --> ROOT
    PIPEYAML --> ROOT
    IN --> ROOT
    OUT --> ROOT
    CHK --> ROOT
    MAN --> ROOT
    ROOT --> ENV --> PIPE --> EXEC
```

### Troubleshooting Flow

```mermaid
%%{init: {"theme": "base", "themeVariables": {"background": "#FFFFFF", "primaryColor": "#FFFFFF", "primaryTextColor": "#1F1F1F", "primaryBorderColor": "#EC0000", "lineColor": "#6B7280", "secondaryColor": "#F7F7F7", "tertiaryColor": "#FFF5F5", "fontFamily": "Arial, Helvetica, sans-serif", "clusterBkg": "#FAFAFA", "clusterBorder": "#D1D5DB", "edgeLabelBackground": "#FFFFFF", "actorBkg": "#FFFFFF", "actorBorder": "#EC0000", "actorTextColor": "#1F1F1F", "activationBkgColor": "#FFF1F1", "activationBorderColor": "#EC0000"}}}%%
flowchart TD
    INC["Incident / job failure"] --> RUN["Identify run_id or execution_id"]
    RUN --> AUDIT["Query Delta Audit Table"]
    AUDIT --> URI["Get artifact_uri"]
    URI --> MANIFEST["Open manifest.yml"]
    MANIFEST --> CHECK["Validate checksums"]
    CHECK --> INSPECT["Inspect catalog.yml<br/>parameters.yml<br/>node.yaml<br/>pipeline.yaml"]
    INSPECT --> DECISION{"Is the redacted snapshot enough?"}
    DECISION -->|Yes| FIX["Diagnose and remediate"]
    DECISION -->|No| BG["Trigger break-glass<br/>full snapshot"]
    BG --> FIX
```

## Base Versions

Declared in `pyproject.toml`:

```text
Python >= 3.11
Kedro >= 1.3.0
kedro-datasets >= 3.0.0
PySpark >= 3.5.0
Delta Spark >= 3.0.0
PyYAML >= 6.0.0
```

## Enterprise Flow

The recommended enterprise flow is:

```text
1. Read metadata
2. Validate metadata
3. Generate Kedro artifacts
4. Create manifest and checksums
5. Publish an immutable snapshot to ADLS
6. Register generation details in an audit table
7. Run Kedro using the materialized artifacts
8. Update execution status and metrics
```

The important rule is:

```text
MongoDB or JSON is the configurable source.
The ADLS snapshot is the official record of execution.
Kedro executes what was materialized.
```

## Project Structure

```text
kedro_Template/
  conf/
    base/
      catalog.yml
      parameters.yml
    local/

  examples/
    metadata/
      orders_metadata.json
      customers_metadata.json
      output_metadata.json

  artifacts/
    generated_runs/

  src/
    kedro_template/
      artifact_generator/
        main.py
        metadata_reader.py
        catalog_generator.py
        parameters_generator.py
        nodes_generator.py
        pipeline_definition_generator.py
        snapshot_publisher.py
        databricks_mount.py

      nodes/
        input_transformations.py
        output_builder.py

      pipelines/
        metadata_engine/
          pipeline.py

      pipeline_registry.py
```

`artifacts/` is ignored by Git because it is execution output, not source code.

## Core Components

### `artifact_generator/main.py`

Main CLI entrypoint. It reads metadata, generates Kedro artifacts, resolves the
artifact destination, creates the execution snapshot, and publishes it.

### `artifact_generator/metadata_reader.py`

Reads metadata from local JSON files and provides a MongoDB reader for the
production path.

### `artifact_generator/catalog_generator.py`

Generates `conf/base/catalog.yml` from input and output metadata.

### `artifact_generator/parameters_generator.py`

Generates `conf/base/parameters.yml`, embedding the materialized metadata under
the `metadata_engine` namespace.

### `artifact_generator/nodes_generator.py`

Generates the node definition artifact at:

```text
conf/base/node.yaml
```

### `artifact_generator/pipeline_definition_generator.py`

Generates the pipeline execution definition artifact at:

```text
conf/base/pipeline.yaml
```

The static Kedro pipeline loader reads `node.yaml` and `pipeline.yaml` at
runtime and materializes the Kedro `Pipeline` object.

### `artifact_generator/snapshot_publisher.py`

Creates the immutable execution snapshot. It copies generated artifacts,
writes metadata snapshots, calculates SHA-256 checksums, creates a manifest,
and publishes the snapshot locally or through Databricks `dbutils.fs`.

### `artifact_generator/databricks_mount.py`

Creates or reuses a Databricks mount point for ADLS. It supports OAuth
authentication through a service principal and Databricks Secrets.

### `nodes/input_transformations.py`

Spark transformation nodes for filtering, field selection, casting, and
metadata-driven column treatments.

### `nodes/output_builder.py`

Spark output assembly nodes for joins, alias handling, final field selection,
and final casts.

## Metadata Model

The template uses two metadata categories:

```text
Input metadata
Output metadata
```

Input metadata describes a source table, filters, fields, types, and
treatments.

Output metadata describes the target table, participating inputs, joins, final
fields, and write behavior.

The main MongoDB relationship is:

```text
output_metadata.pipeline_name
  identifies the pipeline/output definition

output_metadata.inputs[].input_name
  references input_metadata.table_name

input_metadata.pipeline_name
  ensures the input belongs to the same pipeline
```

Supported input treatments currently include:

```text
trim
upper
lower
cast
replace
default
date_format
custom
```

Supported filters include:

```text
=
<>
>
>=
<
<=
IN
NOT IN
IS NULL
IS NOT NULL
```

## Collection Update Flow

This section explains how to evolve MongoDB metadata safely while preserving
traceability, auditability, and predictable artifact generation.

The generator first reads one output definition:

```javascript
db.output_metadata.findOne({
  pipeline_name: "test_pipeline"
})
```

Then it reads all input DataFrame definitions referenced by that output:

```javascript
db.input_metadata.find({
  pipeline_name: "test_pipeline",
  table_name: { $in: ["orders", "customers"] }
})
```

Therefore, every `input_metadata` document used by a pipeline must carry the
same `pipeline_name` as the related `output_metadata` document.

### General Maintenance Rule

In production, avoid deleting metadata as the first action.

Prefer:

```text
is_active = false
```

This keeps operational history easier to inspect. Snapshots preserve what was
executed, but MongoDB should remain readable as the current operational
metadata layer.

### Scenario 1: New table + new field

Use this flow when a new table becomes part of the pipeline.

Example:

```text
Before:
orders + customers

After:
orders + customers + payments
```

Recommended steps:

1. Create a new `input_metadata` document for the new table.
2. Add the table to `output_metadata.inputs`.
3. Add joins to `output_metadata.joins`, if the table must be related to the
   others.
4. Add final fields to `output_metadata.fields`.
5. Review `derived_fields` if a final calculation depends on the new table.
6. Generate artifacts and inspect `node.yaml`, `pipeline.yaml`,
   `parameters.yml`, and `catalog.yml`.

New `input_metadata` document example:

```json
{
  "pipeline_name": "test_pipeline",
  "table_name": "payments",
  "schema": "raw",
  "table": "payments",
  "is_active": true,
  "filters": [],
  "fields": [
    {
      "source_name": "payment_id",
      "target_name": "payment_id",
      "source_type": "string",
      "target_type": "string",
      "is_nullable": false,
      "is_active": true,
      "treatments": []
    }
  ]
}
```

`output_metadata.inputs` example:

```json
{
  "input_name": "payments",
  "alias": "pay",
  "is_base": false,
  "is_active": true
}
```

New join example:

```json
{
  "left_alias": "ord",
  "right_alias": "pay",
  "join_type": "left",
  "conditions": [
    {
      "left_column": "order_id",
      "operator": "=",
      "right_column": "order_id"
    }
  ],
  "order": 2,
  "is_active": true
}
```

Final field from the new table:

```json
{
  "source_alias": "pay",
  "source_name": "payment_id",
  "target_name": "payment_id",
  "target_type": "string",
  "is_active": true
}
```

### Scenario 2: New field + existing table

Use this flow when the table already exists and only a new field must be
treated or published.

Recommended steps:

1. Add the field to `input_metadata.fields` for the existing table.
2. Add the field to `output_metadata.fields` if it must appear in the final
   output table.
3. Add or review `output_metadata.derived_fields` if the new field is used in
   a post-join calculation.
4. Generate artifacts and confirm the field is present in `parameters.yml`.

`input_metadata.fields` example:

```json
{
  "source_name": "order_status",
  "target_name": "order_status",
  "source_type": "string",
  "target_type": "string",
  "is_nullable": true,
  "is_active": true,
  "treatments": [
    {
      "type": "trim",
      "value": null,
      "order": 1
    }
  ]
}
```

`output_metadata.fields` example:

```json
{
  "source_alias": "ord",
  "source_name": "order_status",
  "target_name": "order_status",
  "target_type": "string",
  "is_active": true
}
```

Derived field example using the new field:

```json
{
  "target_name": "is_closed_order",
  "target_type": "boolean",
  "expression": "case when ord.order_status = 'CLOSED' then true else false end",
  "order": 10,
  "is_active": true
}
```

### Scenario 3: Table removal

Use this flow when a table should no longer participate in the pipeline.

Recommended steps:

1. Remove or deactivate the related item in `output_metadata.inputs`.
2. Deactivate joins that reference the removed table alias.
3. Deactivate fields in `output_metadata.fields` that reference that alias.
4. Review `derived_fields`, because expressions may depend on the alias.
5. Deactivate the `input_metadata` document if the table is no longer used by
   the pipeline.
6. Generate artifacts and confirm `node.yaml` no longer contains the removed
   table node.

Logical deactivation in `output_metadata.inputs`:

```json
{
  "input_name": "payments",
  "alias": "pay",
  "is_base": false,
  "is_active": false
}
```

Important note: if the current code does not yet filter `is_active` inside
`output_metadata.inputs`, the safest approach is to remove the item from the
`inputs` array and keep history through metadata versioning or external audit.

Deactivated join example:

```json
{
  "left_alias": "ord",
  "right_alias": "pay",
  "join_type": "left",
  "conditions": [],
  "order": 2,
  "is_active": false
}
```

Deactivated input example:

```json
{
  "pipeline_name": "test_pipeline",
  "table_name": "payments",
  "schema": "raw",
  "table": "payments",
  "is_active": false
}
```

### Scenario 4: Field removal while table remains

Use this flow when the table remains in the pipeline, but one or more fields
should no longer be treated or published.

Recommended steps:

1. Mark the field as `is_active = false` in `input_metadata.fields` if it
   should no longer be read or treated.
2. Mark the field as `is_active = false` in `output_metadata.fields` if it
   should no longer be published in the final table.
3. Review `derived_fields`, because a calculation may depend on the removed
   field.
4. Generate artifacts and inspect `parameters.yml`.

`input_metadata.fields` example:

```json
{
  "source_name": "old_order_code",
  "target_name": "old_order_code",
  "source_type": "string",
  "target_type": "string",
  "is_nullable": true,
  "is_active": false,
  "treatments": []
}
```

`output_metadata.fields` example:

```json
{
  "source_alias": "ord",
  "source_name": "old_order_code",
  "target_name": "old_order_code",
  "target_type": "string",
  "is_active": false
}
```

### Decision Matrix

| Scenario | input_metadata | output_metadata.inputs | output_metadata.joins | output_metadata.fields | output_metadata.derived_fields |
|---|---|---|---|---|---|
| New table + new field | Create document | Add input | Add if needed | Add fields | Review/add if needed |
| New field in existing table | Add field | No change | No change | Add if published | Review/add if calculated |
| Table removal | Deactivate if unused | Remove or deactivate | Deactivate alias joins | Deactivate alias fields | Review expressions |
| Field removal | Deactivate fields | No change | No change | Deactivate fields | Review expressions |

### Pre-Publish Checklist

Before promoting metadata changes, validate:

- `pipeline_name` matches between `output_metadata` and the related
  `input_metadata` documents.
- Every `output_metadata.inputs[].input_name` exists as
  `input_metadata.table_name`.
- Every `source_alias` in `fields` exists in `output_metadata.inputs`.
- Every alias used in `joins` exists in `output_metadata.inputs`.
- Every `derived_fields.expression` uses valid aliases and columns.
- Only one table is marked as `is_base = true`.
- Removed fields are not used by joins or derived fields.
- `partition_columns` exist in the final output, either in `fields` or
  `derived_fields`.
- The snapshot was generated and contains `manifest.yml` and `checksums.json`.

## Generated Artifacts

The generator produces:

```text
conf/base/catalog.yml
conf/base/parameters.yml
src/kedro_template/pipelines/metadata_engine/pipeline.py
```

The snapshot includes:

```text
catalog.yml
parameters.yml
pipeline.py
input_metadata_snapshot.json
output_metadata_snapshot.json
checksums.json
manifest.yml
```

## ADLS Snapshot Publishing

Recommended ADLS layout:

```text
dbfs:/mnt/kedro-artifacts/
  env=prd/
    pipeline=customer_orders_curated/
      execution_id=20260502_153000_customer_orders_curated_ab12cd34/
        catalog.yml
        parameters.yml
        pipeline.py
        input_metadata_snapshot.json
        output_metadata_snapshot.json
        checksums.json
        manifest.yml
```

The snapshot makes the execution independent from the current MongoDB state.
This is essential for incident review, auditability, and replay.

## Databricks Mount Point

Example:

```bash
python -m kedro_template.artifact_generator.main \
  --mount-source abfss://kedro-artifacts@storageaccount.dfs.core.windows.net/ \
  --mount-point /mnt/kedro-artifacts \
  --tenant-id <tenant-id> \
  --client-id <client-id> \
  --client-secret-scope data-platform \
  --client-secret-key sp-client-secret \
  --environment prd \
  --retention-class production \
  --retention-days 730
```

Mount behavior:

- If the mount does not exist, it is created.
- If it exists and points to the same source, it is reused.
- If it exists and points to a different source, execution fails.
- `--force-remount` explicitly unmounts and remounts.

## Snapshot Retention

Recommended starting policy:

```text
dev: 30 days
hml / uat: 90 days
prd: 730 days
prd critical: 1825 days
failed prd: 180 days
```

The `manifest.yml` records:

```yaml
retention:
  class: production
  days: 730
  expires_at: "..."
  legal_hold: false
```

## Troubleshooting and Auditability

During an incident, the team should be able to answer:

```text
Which pipeline ran?
Which metadata was used?
Which catalog.yml was used?
Which parameters.yml was used?
Which pipeline.py was generated?
Which inputs participated?
Which target was written?
Were the artifacts modified?
```

The snapshot provides those answers.

## Running Locally

```powershell
$env:PYTHONPATH='src'
python -m kedro_template.artifact_generator.main --execution-id local_debug
python -m compileall src
```

## Running on Databricks

Generate artifacts and publish the snapshot:

```bash
python -m kedro_template.artifact_generator.main \
  --mount-source abfss://kedro-artifacts@storageaccount.dfs.core.windows.net/ \
  --mount-point /mnt/kedro-artifacts \
  --tenant-id <tenant-id> \
  --client-id <client-id> \
  --client-secret-scope data-platform \
  --client-secret-key sp-client-secret \
  --environment prd \
  --retention-class production \
  --retention-days 730
```

Run Kedro:

```bash
kedro run --pipeline metadata_engine
```

## How Kedro Runs the Generated Pipeline

Kedro uses `pipeline_registry.py` to register:

```text
metadata_engine
__default__
```

The generated pipeline reads:

```text
input_orders
input_customers
```

It produces:

```text
output_customer_orders_curated
```

## Architectural Decisions

### Generate artifacts instead of running only in memory

This improves auditability, debugability, operational clarity, and replay.

### Store execution snapshots in ADLS

ADLS is the natural storage layer in a Databricks and Azure architecture.

### Mount ADLS at runtime

Job clusters may be ephemeral, so the mount must be reproducible at runtime.

### Separate artifact generation from executable nodes

The generator is operational code. Nodes are execution code. Keeping them
separate prevents accidental coupling.

### Keep metadata declarative

Metadata should parameterize common patterns. Complex business logic should
live in versioned Python/Spark code.

## Risks and Mitigations

| Risk | Mitigation |
|---|---|
| Invalid metadata | Schema validation, required input checks, and approval workflow |
| Snapshot not published | Fail the run before executing Kedro |
| Wrong mount point | Validate existing mount source and fail safely |
| Excessive artifact access | Use restricted full snapshots and redacted support snapshots |
| Metadata becomes hidden code | Move complex rules to versioned code |

## Recommended Next Steps

1. Add formal Pydantic validation for metadata.
2. Promote MongoDB as the production metadata source.
3. Add metadata lifecycle statuses: `draft`, `validated`, `approved`, `published`.
4. Create a Delta audit table for generation and execution records.
5. Add a retention cleanup job for ADLS snapshots.
6. Add redacted snapshots for support and incident handling.
7. Add unit tests for each generator module.
8. Add integration tests on Databricks.
9. Support multiple generated pipelines.
10. Evaluate `nodes.yml` and `pipelines.yml` generation if required by the enterprise standard.




