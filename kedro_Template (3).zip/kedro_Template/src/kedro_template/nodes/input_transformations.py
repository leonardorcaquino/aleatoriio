from typing import Dict, Any, List
from pyspark.sql import DataFrame, Column
from pyspark.sql import functions as F


def apply_filters(df: DataFrame, filters: List[Dict[str, Any]]) -> DataFrame:
    for filter_cfg in filters:
        if not filter_cfg.get("is_active", True):
            continue

        column = filter_cfg["column"]
        operator = filter_cfg["operator"].upper()
        value = filter_cfg.get("value")

        if operator == "=":
            df = df.filter(F.col(column) == value)
        elif operator == "<>":
            df = df.filter(F.col(column) != value)
        elif operator == ">":
            df = df.filter(F.col(column) > value)
        elif operator == ">=":
            df = df.filter(F.col(column) >= value)
        elif operator == "<":
            df = df.filter(F.col(column) < value)
        elif operator == "<=":
            df = df.filter(F.col(column) <= value)
        elif operator == "IN":
            df = df.filter(F.col(column).isin(value))
        elif operator == "NOT IN":
            df = df.filter(~F.col(column).isin(value))
        elif operator == "IS NULL":
            df = df.filter(F.col(column).isNull())
        elif operator == "IS NOT NULL":
            df = df.filter(F.col(column).isNotNull())
        else:
            raise ValueError(f"Unsupported filter operator: {operator}")

    return df


def apply_treatment(col_expr: Column, treatment: Dict[str, Any]) -> Column:
    treatment_type = treatment["type"].lower()
    value = treatment.get("value")

    if treatment_type == "trim":
        return F.trim(col_expr)

    if treatment_type == "upper":
        return F.upper(col_expr)

    if treatment_type == "lower":
        return F.lower(col_expr)

    if treatment_type == "cast":
        return col_expr.cast(value)

    if treatment_type == "replace":
        return F.regexp_replace(
            col_expr,
            value["old"],
            value["new"]
        )

    if treatment_type == "default":
        return F.coalesce(col_expr, F.lit(value))

    if treatment_type == "date_format":
        return F.to_date(col_expr, value)

    if treatment_type == "custom":
        return F.expr(value)

    raise ValueError(f"Unsupported treatment type: {treatment_type}")


def build_column_expression(field: Dict[str, Any]) -> Column:
    source_name = field["source_name"]
    target_name = field["target_name"]
    target_type = field.get("target_type")

    col_expr = F.col(source_name)

    treatments = sorted(
        field.get("treatments", []),
        key=lambda x: x.get("order", 0)
    )

    for treatment in treatments:
        col_expr = apply_treatment(col_expr, treatment)

    if target_type:
        col_expr = col_expr.cast(target_type)

    return col_expr.alias(target_name)


def apply_field_selection(
    df: DataFrame,
    fields: List[Dict[str, Any]]
) -> DataFrame:
    selected_columns = [
        build_column_expression(field)
        for field in fields
        if field.get("is_active", True)
    ]

    return df.select(*selected_columns)


def apply_metadata_transformations(
    df: DataFrame,
    config: Dict[str, Any]
) -> DataFrame:
    df = apply_filters(df, config.get("filters", []))
    df = apply_field_selection(df, config.get("fields", []))

    return df
