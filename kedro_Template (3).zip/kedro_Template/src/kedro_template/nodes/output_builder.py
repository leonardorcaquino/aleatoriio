from typing import Dict, Any
from pyspark.sql import DataFrame
from pyspark.sql import functions as F


def build_join_condition(
    left_alias: str,
    right_alias: str,
    conditions: list
):
    condition_expr = None

    for condition in conditions:
        left_col = F.col(f"{left_alias}.{condition['left_column']}")
        right_col = F.col(f"{right_alias}.{condition['right_column']}")
        operator = condition.get("operator", "=")

        if operator == "=":
            current_expr = left_col == right_col
        elif operator == "<>":
            current_expr = left_col != right_col
        elif operator == ">":
            current_expr = left_col > right_col
        elif operator == ">=":
            current_expr = left_col >= right_col
        elif operator == "<":
            current_expr = left_col < right_col
        elif operator == "<=":
            current_expr = left_col <= right_col
        else:
            raise ValueError(f"Unsupported join operator: {operator}")

        condition_expr = (
            current_expr
            if condition_expr is None
            else condition_expr & current_expr
        )

    return condition_expr


def apply_joins(
    dfs: Dict[str, DataFrame],
    output_config: Dict[str, Any]
) -> DataFrame:
    inputs = output_config["inputs"]

    base_input = next(
        input_cfg for input_cfg in inputs
        if input_cfg.get("is_base")
    )

    base_alias = base_input["alias"]

    aliased_dfs = {
        input_cfg["alias"]: dfs[input_cfg["input_name"]].alias(input_cfg["alias"])
        for input_cfg in inputs
    }

    result_df = aliased_dfs[base_alias]

    joins = sorted(
        [
            join_cfg
            for join_cfg in output_config.get("joins", [])
            if join_cfg.get("is_active", True)
        ],
        key=lambda x: x.get("order", 0)
    )

    for join_cfg in joins:
        right_alias = join_cfg["right_alias"]

        join_condition = build_join_condition(
            left_alias=join_cfg["left_alias"],
            right_alias=right_alias,
            conditions=join_cfg["conditions"]
        )

        result_df = result_df.join(
            aliased_dfs[right_alias],
            on=join_condition,
            how=join_cfg.get("join_type", "left")
        )

    return result_df


def apply_output_field_selection(
    df: DataFrame,
    output_config: Dict[str, Any]
) -> DataFrame:
    selected_columns = []

    for field in output_config.get("fields", []):
        if not field.get("is_active", True):
            continue

        col_expr = F.col(f"{field['source_alias']}.{field['source_name']}")

        if field.get("target_type"):
            col_expr = col_expr.cast(field["target_type"])

        selected_columns.append(col_expr.alias(field["target_name"]))

    derived_fields = sorted(
        [
            field
            for field in output_config.get("derived_fields", [])
            if field.get("is_active", True)
        ],
        key=lambda x: x.get("order", 0)
    )

    for field in derived_fields:
        col_expr = build_derived_field_expression(field)
        selected_columns.append(col_expr)

    return df.select(*selected_columns)


def build_derived_field_expression(field: Dict[str, Any]):
    col_expr = F.expr(field["expression"])

    if field.get("target_type"):
        col_expr = col_expr.cast(field["target_type"])

    return col_expr.alias(field["target_name"])


def build_output_dataframe(
    dfs: Dict[str, DataFrame],
    output_config: Dict[str, Any]
) -> DataFrame:
    joined_df = apply_joins(dfs, output_config)
    output_df = apply_output_field_selection(joined_df, output_config)

    return output_df


def build_output_dataframe_from_ordered_inputs(*args) -> DataFrame:
    *dataframes, output_config = args

    input_names = [
        input_cfg["input_name"]
        for input_cfg in output_config.get("inputs", [])
    ]

    if len(dataframes) != len(input_names):
        raise ValueError(
            "The number of input DataFrames does not match the output metadata."
        )

    dfs = dict(zip(input_names, dataframes))
    return build_output_dataframe(dfs, output_config)
