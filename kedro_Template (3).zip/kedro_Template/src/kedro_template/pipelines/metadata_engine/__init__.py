"""Metadata-driven generated pipeline."""

