from __future__ import annotations

from importlib import import_module
from pathlib import Path
from typing import Any, Dict, List

import yaml
from kedro.pipeline import Pipeline, node, pipeline


def create_pipeline(**kwargs) -> Pipeline:
    node_definition_path = Path(kwargs.get("node_definition_path", "conf/base/node.yaml"))
    pipeline_definition_path = Path(
        kwargs.get("pipeline_definition_path", "conf/base/pipeline.yaml")
    )

    if not node_definition_path.exists() or not pipeline_definition_path.exists():
        return Pipeline([])

    node_definition = _read_yaml(node_definition_path)
    pipeline_definition = _read_yaml(pipeline_definition_path)

    node_configs = {
        node_config["name"]: node_config
        for node_config in node_definition.get("nodes", [])
    }
    execution_order = pipeline_definition.get("pipeline", {}).get("execution_order", [])

    kedro_nodes = [
        _build_kedro_node(node_configs[node_name])
        for node_name in execution_order
        if node_name in node_configs
    ]

    return pipeline(kedro_nodes)


def _read_yaml(path: Path) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as file:
        return yaml.safe_load(file) or {}


def _build_kedro_node(node_config: Dict[str, Any]):
    return node(
        func=_resolve_function(node_config["function"]),
        inputs=node_config["inputs"],
        outputs=node_config["outputs"],
        name=node_config["name"],
        tags=_resolve_tags(node_config),
    )


def _resolve_function(function_path: str):
    module_name, function_name = function_path.rsplit(".", 1)
    module = import_module(module_name)
    return getattr(module, function_name)


def _resolve_tags(node_config: Dict[str, Any]) -> List[str] | None:
    tags = node_config.get("tags")
    if not tags:
        return None
    return tags
