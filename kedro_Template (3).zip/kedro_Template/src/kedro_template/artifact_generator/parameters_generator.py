from typing import Dict, Any, List
from pathlib import Path
import yaml

def clean_mongo_document(document: Dict[str, Any]) -> Dict[str, Any]:
    document = dict(document)
    document.pop("_id", None)
    return document


def generate_parameters_yml(
    input_configs: List[Dict[str, Any]],
    output_config: Dict[str, Any],
    output_path: str = "conf/base/parameters.yml"
) -> None:

    input_params = {
        cfg["table_name"]: clean_mongo_document(cfg)
        for cfg in input_configs
    }

    params = {
        "metadata_engine": {
            "pipeline_name": output_config["pipeline_name"],
            "output_name": output_config["output_name"],
            "input_configs": input_params,
            "output_config": clean_mongo_document(output_config)
        }
    }

    Path(output_path).parent.mkdir(parents=True, exist_ok=True)

    with open(output_path, "w", encoding="utf-8") as file:
        yaml.dump(
            params,
            file,
            sort_keys=False,
            allow_unicode=True
        )
