"""Create and publish generated Kedro artifact snapshots."""

from __future__ import annotations

import hashlib
import json
import shutil
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any
from uuid import uuid4

import yaml


@dataclass(frozen=True)
class ArtifactSnapshot:
    """Result of a generated artifact snapshot publication."""

    execution_id: str
    local_path: Path
    artifact_uri: str
    manifest_path: Path
    checksums_path: Path


def create_artifact_snapshot(
    input_configs: list[dict[str, Any]],
    output_config: dict[str, Any],
    generated_files: dict[str, str],
    artifact_base_uri: str = "artifacts/generated_runs",
    environment: str = "dev",
    retention_class: str = "standard",
    retention_days: int = 180,
    execution_id: str | None = None,
) -> ArtifactSnapshot:
    """Materialize and publish a snapshot of the generated Kedro artifacts."""
    output_name = output_config["output_name"]
    generated_at = datetime.now(timezone.utc)
    execution_id = execution_id or _new_execution_id(output_name, generated_at)
    local_path = _local_snapshot_path(environment, output_name, execution_id)
    local_path.mkdir(parents=True, exist_ok=True)

    copied_files = _copy_generated_files(generated_files, local_path)
    metadata_files = _write_metadata_snapshots(input_configs, output_config, local_path)
    checksums = _write_checksums({**copied_files, **metadata_files}, local_path)
    artifact_uri = _artifact_uri(artifact_base_uri, environment, output_name, execution_id)

    manifest_path = _write_manifest(
        local_path=local_path,
        execution_id=execution_id,
        environment=environment,
        output_name=output_name,
        output_config=output_config,
        generated_at=generated_at,
        artifact_uri=artifact_uri,
        retention_class=retention_class,
        retention_days=retention_days,
        files={**copied_files, **metadata_files},
        checksums=checksums,
    )
    checksums_path = local_path / "checksums.json"

    _publish_snapshot(local_path, artifact_uri)

    return ArtifactSnapshot(
        execution_id=execution_id,
        local_path=local_path,
        artifact_uri=artifact_uri,
        manifest_path=manifest_path,
        checksums_path=checksums_path,
    )


def _new_execution_id(output_name: str, generated_at: datetime) -> str:
    timestamp = generated_at.strftime("%Y%m%d_%H%M%S")
    return f"{timestamp}_{_safe_path_part(output_name)}_{uuid4().hex[:8]}"


def _local_snapshot_path(environment: str, output_name: str, execution_id: str) -> Path:
    return (
        Path("artifacts")
        / "generated_runs"
        / f"env={_safe_path_part(environment)}"
        / f"pipeline={_safe_path_part(output_name)}"
        / f"execution_id={_safe_path_part(execution_id)}"
    )


def _artifact_uri(
    artifact_base_uri: str,
    environment: str,
    output_name: str,
    execution_id: str,
) -> str:
    base = artifact_base_uri.rstrip("/\\")
    suffix = "/".join(
        [
            f"env={_safe_path_part(environment)}",
            f"pipeline={_safe_path_part(output_name)}",
            f"execution_id={_safe_path_part(execution_id)}",
        ]
    )
    return f"{base}/{suffix}"


def _copy_generated_files(generated_files: dict[str, str], local_path: Path) -> dict[str, str]:
    copied_files = {}
    for logical_name, file_path in generated_files.items():
        source = Path(file_path)
        if not source.exists():
            raise FileNotFoundError(f"Generated artifact not found: {source}")
        target = local_path / source.name
        shutil.copy2(source, target)
        copied_files[logical_name] = target.name
    return copied_files


def _write_metadata_snapshots(
    input_configs: list[dict[str, Any]],
    output_config: dict[str, Any],
    local_path: Path,
) -> dict[str, str]:
    input_snapshot = local_path / "input_metadata_snapshot.json"
    output_snapshot = local_path / "output_metadata_snapshot.json"

    input_snapshot.write_text(
        json.dumps(_json_safe(input_configs), indent=2, sort_keys=True),
        encoding="utf-8",
    )
    output_snapshot.write_text(
        json.dumps(_json_safe(output_config), indent=2, sort_keys=True),
        encoding="utf-8",
    )

    return {
        "input_metadata_snapshot": input_snapshot.name,
        "output_metadata_snapshot": output_snapshot.name,
    }


def _write_checksums(files: dict[str, str], local_path: Path) -> dict[str, str]:
    checksums = {
        file_name: _sha256_file(local_path / file_name)
        for file_name in files.values()
    }
    checksums_path = local_path / "checksums.json"
    checksums_path.write_text(
        json.dumps(checksums, indent=2, sort_keys=True),
        encoding="utf-8",
    )
    return checksums


def _write_manifest(
    local_path: Path,
    execution_id: str,
    environment: str,
    output_name: str,
    output_config: dict[str, Any],
    generated_at: datetime,
    artifact_uri: str,
    retention_class: str,
    retention_days: int,
    files: dict[str, str],
    checksums: dict[str, str],
) -> Path:
    expires_at = generated_at + timedelta(days=retention_days)
    manifest = {
        "execution_id": execution_id,
        "environment": environment,
        "pipeline_name": output_name,
        "generated_at": generated_at.isoformat(),
        "artifact_uri": artifact_uri,
        "target": {
            "catalog": output_config.get("catalog"),
            "schema": output_config.get("schema"),
            "table": output_config.get("table"),
            "dataset": f"output_{output_name}",
        },
        "retention": {
            "class": retention_class,
            "days": retention_days,
            "expires_at": expires_at.isoformat(),
            "legal_hold": False,
        },
        "files": files,
        "checksums": checksums,
        "status": "snapshot_created",
    }

    manifest_path = local_path / "manifest.yml"
    manifest_path.write_text(
        yaml.dump(manifest, sort_keys=False, allow_unicode=True),
        encoding="utf-8",
    )
    return manifest_path


def _publish_snapshot(local_path: Path, artifact_uri: str) -> None:
    if _is_databricks_uri(artifact_uri):
        _publish_to_databricks_fs(local_path, artifact_uri)
        return

    target_path = Path(artifact_uri)
    if target_path.resolve() == local_path.resolve():
        return
    if target_path.exists():
        shutil.rmtree(target_path)
    shutil.copytree(local_path, target_path)


def _publish_to_databricks_fs(local_path: Path, artifact_uri: str) -> None:
    dbutils = _get_dbutils()
    dbutils.fs.mkdirs(artifact_uri)
    for source in local_path.rglob("*"):
        if source.is_dir():
            continue
        relative_path = source.relative_to(local_path).as_posix()
        target_uri = f"{artifact_uri.rstrip('/')}/{relative_path}"
        dbutils.fs.cp(_local_file_uri(source), target_uri, True)


def _get_dbutils() -> Any:
    try:
        return dbutils  # type: ignore[name-defined]
    except NameError:
        pass

    try:
        from pyspark.sql import SparkSession
        from pyspark.dbutils import DBUtils
    except ImportError as exc:
        raise RuntimeError(
            "Publishing to ADLS requires Databricks dbutils. "
            "Run this generator in Databricks or publish to a local path."
        ) from exc

    spark = SparkSession.builder.getOrCreate()
    return DBUtils(spark)


def _local_file_uri(path: Path) -> str:
    absolute_path = path.resolve()
    if absolute_path.drive:
        return absolute_path.as_uri()
    return f"file:{absolute_path.as_posix()}"


def _is_databricks_uri(uri: str) -> bool:
    return (
        uri.startswith("abfss://")
        or uri.startswith("abfs://")
        or uri.startswith("dbfs:/")
    )


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as file:
        for chunk in iter(lambda: file.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _json_safe(value: Any) -> Any:
    if isinstance(value, dict):
        return {key: _json_safe(item) for key, item in value.items() if key != "_id"}
    if isinstance(value, list):
        return [_json_safe(item) for item in value]
    if isinstance(value, datetime):
        return value.isoformat()
    return value


def _safe_path_part(value: str) -> str:
    return "".join(
        character if character.isalnum() or character in {"-", "_", "="} else "_"
        for character in value
    )
