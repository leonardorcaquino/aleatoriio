"""Read metadata used by the Kedro artifact generator."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any


def read_metadata_from_files(
    input_metadata_path: str | Path = "examples/metadata",
    output_metadata_path: str | Path = "examples/metadata/output_metadata.json",
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Read local JSON metadata files.

    When `input_metadata_path` is a directory, only files ending with
    `_metadata.json` are treated as input metadata documents, excluding the
    configured output metadata file.
    """
    output_config = _read_json(output_metadata_path)
    input_config = _read_input_metadata(input_metadata_path, output_metadata_path)

    input_configs = input_config if isinstance(input_config, list) else [input_config]
    _validate_required_inputs(input_configs, output_config)
    return input_configs, output_config


def read_metadata_from_mongo(
    mongo_uri: str,
    database: str,
    input_collection: str,
    output_collection: str,
    pipeline_name: str,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Read metadata from MongoDB when pymongo is available."""
    try:
        from pymongo import MongoClient
    except ImportError as exc:
        raise ImportError(
            "pymongo is required to read metadata from MongoDB. "
            "Install it or use read_metadata_from_files for local JSON metadata."
        ) from exc

    client = MongoClient(mongo_uri)
    db = client[database]
    output_config = db[output_collection].find_one({"pipeline_name": pipeline_name})
    if output_config is None:
        raise ValueError(f"Output metadata not found for pipeline_name={pipeline_name!r}")

    input_names = [item["input_name"] for item in output_config.get("inputs", [])]
    input_configs = list(
        db[input_collection].find(
            {
                "pipeline_name": pipeline_name,
                "table_name": {"$in": input_names},
            }
        )
    )
    found_inputs = {item["table_name"] for item in input_configs}
    missing_inputs = sorted(set(input_names) - found_inputs)
    if missing_inputs:
        raise ValueError(
            "Input metadata not found for "
            f"pipeline_name={pipeline_name!r}: {missing_inputs}"
        )

    return input_configs, output_config


def _read_json(path: str | Path) -> Any:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def _read_input_metadata(
    input_metadata_path: str | Path,
    output_metadata_path: str | Path,
) -> Any:
    path = Path(input_metadata_path)
    if path.is_file():
        return _read_json(path)

    output_path = Path(output_metadata_path).resolve()
    input_configs = []
    for candidate in sorted(path.glob("*_metadata.json")):
        if candidate.resolve() == output_path:
            continue
        payload = _read_json(candidate)
        if isinstance(payload, dict) and _is_input_metadata(payload):
            input_configs.append(payload)
        elif isinstance(payload, list):
            input_configs.extend([item for item in payload if _is_input_metadata(item)])
    return input_configs


def _is_input_metadata(payload: dict[str, Any]) -> bool:
    return "table_name" in payload and "inputs" not in payload


def _validate_required_inputs(
    input_configs: list[dict[str, Any]],
    output_config: dict[str, Any],
) -> None:
    required_inputs = {item["input_name"] for item in output_config.get("inputs", [])}
    available_inputs = {item["table_name"] for item in input_configs}
    missing_inputs = sorted(required_inputs - available_inputs)
    if missing_inputs:
        raise ValueError(f"Missing input metadata for: {missing_inputs}")
