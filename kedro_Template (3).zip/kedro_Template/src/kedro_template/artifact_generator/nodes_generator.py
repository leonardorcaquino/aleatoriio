from pathlib import Path
from typing import Any, Dict, List

import yaml


INPUT_TRANSFORMATION_FUNCTION = (
    "kedro_template.nodes.input_transformations.apply_metadata_transformations"
)
OUTPUT_BUILDER_FUNCTION = (
    "kedro_template.nodes.output_builder.build_output_dataframe_from_ordered_inputs"
)


def generate_node_yml(
    output_config: Dict[str, Any],
    output_path: str = "conf/base/node.yaml",
) -> None:
    """Generate the YAML artifact that describes Kedro node definitions."""

    nodes = [
        _build_input_transformation_node(input_cfg=input_cfg, order=index)
        for index, input_cfg in enumerate(output_config.get("inputs", []), start=1)
    ]
    nodes.append(_build_output_builder_node(output_config=output_config))

    node_definition = {
        "schema_version": 1,
        "kind": "kedro_node_definition",
        "nodes": nodes,
    }

    Path(output_path).parent.mkdir(parents=True, exist_ok=True)

    with open(output_path, "w", encoding="utf-8") as file:
        yaml.dump(
            node_definition,
            file,
            sort_keys=False,
            allow_unicode=True,
        )


def _build_input_transformation_node(
    input_cfg: Dict[str, Any],
    order: int,
) -> Dict[str, Any]:
    input_name = input_cfg["input_name"]

    return {
        "name": f"transform_{input_name}_node",
        "function": INPUT_TRANSFORMATION_FUNCTION,
        "inputs": [
            f"input_{input_name}",
            f"params:metadata_engine.input_configs.{input_name}",
        ],
        "outputs": f"{input_name}_treated",
        "tags": [
            "metadata_engine",
            "input_transformation",
        ],
        "metadata": {
            "order": order,
            "node_type": "input_transformation",
            "input_name": input_name,
            "alias": input_cfg.get("alias"),
            "is_base": input_cfg.get("is_base", False),
        },
    }


def _build_output_builder_node(output_config: Dict[str, Any]) -> Dict[str, Any]:
    output_name = output_config["output_name"]
    input_names = _get_ordered_input_names(output_config)

    return {
        "name": f"build_{output_name}_node",
        "function": OUTPUT_BUILDER_FUNCTION,
        "inputs": [
            *[f"{input_name}_treated" for input_name in input_names],
            "params:metadata_engine.output_config",
        ],
        "outputs": f"output_{output_name}",
        "tags": [
            "metadata_engine",
            "output_builder",
        ],
        "metadata": {
            "order": len(input_names) + 1,
            "node_type": "output_builder",
            "pipeline_name": output_config.get("pipeline_name"),
            "output_name": output_name,
        },
    }


def _get_ordered_input_names(output_config: Dict[str, Any]) -> List[str]:
    return [
        input_cfg["input_name"]
        for input_cfg in output_config.get("inputs", [])
    ]
