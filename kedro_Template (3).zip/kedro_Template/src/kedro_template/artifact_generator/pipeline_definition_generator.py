from pathlib import Path
from typing import Any, Dict, List

import yaml


def generate_pipeline_definition_yml(
    output_config: Dict[str, Any],
    output_path: str = "conf/base/pipeline.yaml",
) -> None:
    """Generate the YAML artifact that defines the pipeline execution order."""

    input_names = _get_ordered_input_names(output_config)
    transform_node_names = [
        f"transform_{input_name}_node"
        for input_name in input_names
    ]
    build_node_name = f"build_{output_config['output_name']}_node"

    pipeline_definition = {
        "schema_version": 1,
        "kind": "kedro_pipeline_definition",
        "pipeline": {
            "name": output_config["pipeline_name"],
            "output_name": output_config["output_name"],
            "description": output_config.get("description"),
            "execution_order": [
                *transform_node_names,
                build_node_name,
            ],
            "inputs": [
                f"input_{input_name}"
                for input_name in input_names
            ],
            "outputs": [
                f"output_{output_config['output_name']}",
            ],
            "tags": [
                "metadata_engine",
                output_config["pipeline_name"],
            ],
            "metadata": {
                "layer": output_config.get("layer"),
                "schema": output_config.get("schema"),
                "table": output_config.get("table"),
                "retention_policy": output_config.get("retention_policy"),
            },
        },
    }

    Path(output_path).parent.mkdir(parents=True, exist_ok=True)

    with open(output_path, "w", encoding="utf-8") as file:
        yaml.dump(
            pipeline_definition,
            file,
            sort_keys=False,
            allow_unicode=True,
        )


def _get_ordered_input_names(output_config: Dict[str, Any]) -> List[str]:
    return [
        input_cfg["input_name"]
        for input_cfg in output_config.get("inputs", [])
    ]
