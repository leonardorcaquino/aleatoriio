from __future__ import annotations

import argparse

from kedro_template.artifact_generator.catalog_generator import generate_catalog_yml
from kedro_template.artifact_generator.databricks_mount import (
    ensure_adls_mount,
    mount_point_to_dbfs_uri,
)
from kedro_template.artifact_generator.metadata_reader import read_metadata_from_files
from kedro_template.artifact_generator.nodes_generator import generate_node_yml
from kedro_template.artifact_generator.parameters_generator import generate_parameters_yml
from kedro_template.artifact_generator.pipeline_definition_generator import (
    generate_pipeline_definition_yml,
)
from kedro_template.artifact_generator.snapshot_publisher import create_artifact_snapshot


def main() -> None:
    args = _parse_args()

    input_configs, output_config = read_metadata_from_files(
        input_metadata_path=args.input_metadata_path,
        output_metadata_path=args.output_metadata_path,
    )

    generate_catalog_yml(
        input_configs=input_configs,
        output_config=output_config,
        output_path=args.catalog_output_path,
    )

    generate_parameters_yml(
        input_configs=input_configs,
        output_config=output_config,
        output_path=args.parameters_output_path,
    )

    generate_node_yml(
        output_config=output_config,
        output_path=args.node_output_path,
    )

    generate_pipeline_definition_yml(
        output_config=output_config,
        output_path=args.pipeline_definition_output_path,
    )

    artifact_base_uri = _resolve_artifact_base_uri(args)

    snapshot = create_artifact_snapshot(
        input_configs=input_configs,
        output_config=output_config,
        generated_files={
            "catalog": args.catalog_output_path,
            "parameters": args.parameters_output_path,
            "node_definition": args.node_output_path,
            "pipeline_definition": args.pipeline_definition_output_path,
        },
        artifact_base_uri=artifact_base_uri,
        environment=args.environment,
        retention_class=args.retention_class,
        retention_days=args.retention_days,
        execution_id=args.execution_id,
    )

    print(f"Generated artifact snapshot: {snapshot.artifact_uri}")


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Generate Kedro artifacts and publish an execution snapshot.",
    )
    parser.add_argument("--input-metadata-path", default="examples/metadata")
    parser.add_argument(
        "--output-metadata-path",
        default="examples/metadata/output_metadata.json",
    )
    parser.add_argument("--catalog-output-path", default="conf/base/catalog.yml")
    parser.add_argument("--parameters-output-path", default="conf/base/parameters.yml")
    parser.add_argument("--node-output-path", default="conf/base/node.yaml")
    parser.add_argument(
        "--pipeline-definition-output-path",
        default="conf/base/pipeline.yaml",
    )
    parser.add_argument(
        "--artifact-base-uri",
        default="artifacts/generated_runs",
        help=(
            "Local folder or ADLS URI, for example "
            "abfss://container@account.dfs.core.windows.net/kedro-artifacts"
        ),
    )
    parser.add_argument(
        "--mount-source",
        default=None,
        help=(
            "ADLS source URI to mount, for example "
            "abfss://container@account.dfs.core.windows.net/"
        ),
    )
    parser.add_argument(
        "--mount-point",
        default=None,
        help="Databricks mount point, for example /mnt/kedro-artifacts.",
    )
    parser.add_argument("--tenant-id", default=None)
    parser.add_argument("--client-id", default=None)
    parser.add_argument("--client-secret-scope", default=None)
    parser.add_argument("--client-secret-key", default=None)
    parser.add_argument("--force-remount", action="store_true")
    parser.add_argument("--environment", default="dev")
    parser.add_argument("--retention-class", default="standard")
    parser.add_argument("--retention-days", type=int, default=180)
    parser.add_argument("--execution-id", default=None)
    return parser.parse_args()


def _resolve_artifact_base_uri(args: argparse.Namespace) -> str:
    if not args.mount_point:
        return args.artifact_base_uri

    if args.mount_source:
        mount_point = ensure_adls_mount(
            mount_source=args.mount_source,
            mount_point=args.mount_point,
            tenant_id=args.tenant_id,
            client_id=args.client_id,
            client_secret_scope=args.client_secret_scope,
            client_secret_key=args.client_secret_key,
            force_remount=args.force_remount,
        )
    else:
        mount_point = args.mount_point

    return mount_point_to_dbfs_uri(mount_point)


if __name__ == "__main__":
    main()
