"""Databricks mount helpers for publishing artifact snapshots."""

from __future__ import annotations

from typing import Any


def ensure_adls_mount(
    mount_source: str,
    mount_point: str,
    tenant_id: str | None = None,
    client_id: str | None = None,
    client_secret_scope: str | None = None,
    client_secret_key: str | None = None,
    force_remount: bool = False,
) -> str:
    """Create an ADLS mount point when it does not already exist.

    Parameters are intentionally explicit so secrets can come from Databricks
    Secrets instead of command-line plaintext.
    """
    dbutils = get_dbutils()
    normalized_mount_point = normalize_mount_point(mount_point)
    existing_mount = _find_mount(dbutils, normalized_mount_point)

    if existing_mount and _same_source(existing_mount.source, mount_source):
        dbutils.fs.refreshMounts()
        return normalized_mount_point

    if existing_mount and not force_remount:
        raise ValueError(
            f"Mount point {normalized_mount_point!r} already exists with source "
            f"{existing_mount.source!r}. Use --force-remount to replace it."
        )

    if existing_mount and force_remount:
        dbutils.fs.unmount(normalized_mount_point)

    extra_configs = _oauth_configs(
        dbutils=dbutils,
        tenant_id=tenant_id,
        client_id=client_id,
        client_secret_scope=client_secret_scope,
        client_secret_key=client_secret_key,
    )
    dbutils.fs.mount(
        source=mount_source,
        mount_point=normalized_mount_point,
        extra_configs=extra_configs,
    )
    dbutils.fs.refreshMounts()
    return normalized_mount_point


def normalize_mount_point(mount_point: str) -> str:
    """Normalize DBFS mount point for dbutils.fs.mount."""
    if mount_point.startswith("dbfs:"):
        mount_point = mount_point.replace("dbfs:", "", 1)
    if not mount_point.startswith("/"):
        mount_point = f"/{mount_point}"
    return mount_point.rstrip("/")


def mount_point_to_dbfs_uri(mount_point: str) -> str:
    """Convert /mnt/foo into dbfs:/mnt/foo for dbutils.fs file operations."""
    normalized_mount_point = normalize_mount_point(mount_point)
    return f"dbfs:{normalized_mount_point}"


def get_dbutils() -> Any:
    """Return Databricks dbutils from notebook or job context."""
    try:
        return dbutils  # type: ignore[name-defined]
    except NameError:
        pass

    try:
        from pyspark.sql import SparkSession
        from pyspark.dbutils import DBUtils
    except ImportError as exc:
        raise RuntimeError(
            "Databricks dbutils is required for mount operations. "
            "Run this command inside Databricks."
        ) from exc

    spark = SparkSession.builder.getOrCreate()
    return DBUtils(spark)


def _find_mount(dbutils: Any, mount_point: str) -> Any | None:
    for mount in dbutils.fs.mounts():
        if mount.mountPoint.rstrip("/") == mount_point:
            return mount
    return None


def _same_source(existing_source: str, expected_source: str) -> bool:
    return existing_source.rstrip("/") == expected_source.rstrip("/")


def _oauth_configs(
    dbutils: Any,
    tenant_id: str | None,
    client_id: str | None,
    client_secret_scope: str | None,
    client_secret_key: str | None,
) -> dict[str, str]:
    provided = [tenant_id, client_id, client_secret_scope, client_secret_key]
    if not any(provided):
        return {}
    if not all(provided):
        raise ValueError(
            "Service principal mount requires tenant_id, client_id, "
            "client_secret_scope and client_secret_key."
        )

    client_secret = dbutils.secrets.get(
        scope=client_secret_scope,
        key=client_secret_key,
    )
    return {
        "fs.azure.account.auth.type": "OAuth",
        "fs.azure.account.oauth.provider.type": (
            "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider"
        ),
        "fs.azure.account.oauth2.client.id": client_id,
        "fs.azure.account.oauth2.client.secret": client_secret,
        "fs.azure.account.oauth2.client.endpoint": (
            f"https://login.microsoftonline.com/{tenant_id}/oauth2/token"
        ),
    }
