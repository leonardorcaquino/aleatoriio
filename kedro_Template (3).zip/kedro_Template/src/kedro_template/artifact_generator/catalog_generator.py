from pathlib import Path
from typing import Dict, Any, List
import yaml


def generate_catalog_yml(
    input_configs: List[Dict[str, Any]],
    output_config: Dict[str, Any],
    output_path: str = "conf/base/catalog.yml"
) -> None:

    catalog = {}

    for cfg in input_configs:
        dataset_name = f"input_{cfg['table_name']}"

        catalog[dataset_name] = _spark_dataset_config(
            metadata=cfg,
            default_format=cfg.get("format", "delta"),
        )

    output_dataset_name = f"output_{output_config['output_name']}"

    catalog[output_dataset_name] = _spark_dataset_config(
        metadata=output_config,
        default_format=output_config.get("write", {}).get("format", "delta"),
    )
    catalog[output_dataset_name]["save_args"] = {
        "mode": output_config.get("write", {}).get("mode", "overwrite"),
        "is_stage": output_config.get("write", {}).get("is_stage", True)
    }

    partition_columns = output_config.get("write", {}).get("partition_columns", [])

    if partition_columns:
        catalog[output_dataset_name]["save_args"]["partitionBy"] = partition_columns

    Path(output_path).parent.mkdir(parents=True, exist_ok=True)

    with open(output_path, "w", encoding="utf-8") as file:
        yaml.dump(
            catalog,
            file,
            sort_keys=False,
            allow_unicode=True
        )


def _spark_dataset_config(
    metadata: Dict[str, Any],
    default_format: str = "delta",
) -> Dict[str, Any]:
    dataset_config = {
        "type": "spark.SparkDataset",
        "file_format": default_format,
    }

    if metadata.get("path"):
        dataset_config["filepath"] = metadata["path"]
        return dataset_config

    dataset_config["table_name"] = metadata.get("table") or metadata["table_name"]
    dataset_config["schema_name"] = metadata.get("schema") or metadata.get("schema_name")
    return dataset_config
