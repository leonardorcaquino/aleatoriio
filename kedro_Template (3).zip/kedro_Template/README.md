﻿# Metadata-Driven Processing Engine.

**Idioma:** Português (Brasil) | [English (US)](README.en-US.md)

![Status](https://img.shields.io/badge/status-enterprise%20template-EC0000?style=flat-square)
![Runtime](https://img.shields.io/badge/runtime-Databricks-EC0000?style=flat-square)
![Framework](https://img.shields.io/badge/framework-Kedro-1F1F1F?style=flat-square)
![Storage](https://img.shields.io/badge/storage-ADLS-6B7280?style=flat-square)

Template enterprise para geracao de artefatos Kedro a partir de metadados,
com execucao em Databricks, publicacao de snapshots em ADLS e suporte a
auditoria, debug e replay de execucoes.

Este projeto foi desenhado para um cenario em que pipelines de dados precisam
ser configuraveis por metadados, mas ainda precisam produzir artefatos
explicitos e auditaveis, como `catalog.yml`, `parameters.yml`, `node.yaml` e `pipeline.yaml`.

## Sumario

- [Objetivo](#objetivo)
- [Tese da arquitetura](#tese-da-arquitetura)
- [Diretrizes visuais](#diretrizes-visuais)
- [Diagramas da solucao](#diagramas-da-solucao)
- [Versoes base](#versoes-base)
- [Fluxo enterprise](#fluxo-enterprise)
- [Estrutura do projeto](#estrutura-do-projeto)
- [Componentes principais](#componentes-principais)
- [Modelo de metadados](#modelo-de-metadados)
- [Fluxo de atualizacao das collections](#fluxo-de-atualizacao-das-collections)
- [Artefatos gerados](#artefatos-gerados)
- [Snapshot e publicacao no ADLS](#snapshot-e-publicacao-no-adls)
- [Mount point em Databricks](#mount-point-em-databricks)
- [Retencao de snapshots](#retencao-de-snapshots)
- [Troubleshooting e auditoria](#troubleshooting-e-auditoria)
- [Como executar localmente](#como-executar-localmente)
- [Como executar no Databricks](#como-executar-no-databricks)
- [Como o Kedro executa a pipeline gerada](#como-o-kedro-executa-a-pipeline-gerada)
- [Decisoes arquiteturais](#decisoes-arquiteturais)
- [Riscos e mitigacoes](#riscos-e-mitigacoes)
- [Proximos passos recomendados](#proximos-passos-recomendados)

## Objetivo

O objetivo deste template e materializar pipelines Kedro a partir de
metadados.

Em vez de criar manualmente todos os arquivos Kedro para cada pipeline, a
solucao le documentos de metadados e gera:

- `conf/base/catalog.yml`
- `conf/base/parameters.yml`
- `conf/base/node.yaml`
- `conf/base/pipeline.yaml`
- snapshots de metadados
- `manifest.yml`
- `checksums.json`

Depois disso, o Kedro executa artefatos concretos, visiveis e rastreaveis.

Essa abordagem evita uma pipeline totalmente dinamica em memoria, que pode ser
dificil de auditar, e combina flexibilidade de metadados com governanca
enterprise.

## Tese da arquitetura

A tese central e:

```text
Metadados definem a intencao.
Artefatos materializados definem a execucao.
Snapshots garantem auditoria e replay.
Kedro executa um contrato explicito.
```

Separacao de responsabilidades:

```text
MongoDB ou arquivos JSON
  Camada operacional/editavel de metadados

Artifact Generator
  Materializa catalogo, parametros, nodes e definicao de pipeline Kedro

ADLS
  Armazena snapshot imutavel do que foi gerado/executado

Kedro
  Executa a pipeline usando artefatos materializados

Databricks
  Runtime Spark e ambiente de execucao

Delta Tables
  Camada de dados, governanca e auditoria pesquisavel
```

## Diretrizes visuais

O README usa uma identidade visual corporativa, inspirada em ambientes financeiros e adequada para apresentacao a times enterprise.

| Elemento | Uso |
|---|---|
| Vermelho `#EC0000` | Destaques, bordas principais e elementos criticos |
| Preto `#1F1F1F` | Texto principal e componentes estruturais |
| Cinza `#6B7280` | Linhas, conectores e informacoes secundarias |
| Cinza claro `#F7F7F7` | Agrupamentos e areas de apoio |
| Branco `#FFFFFF` | Fundo principal e leitura limpa |

Principios aplicados:

- diagramas limpos, sem logos dentro dos fluxogramas;
- logos somente nas tabelas de legenda;
- vermelho usado como destaque, nao como preenchimento dominante;
- layout com alto contraste e leitura rapida;
- textos curtos dentro dos nos para facilitar apresentacoes.

## Diagramas da solucao

Esta secao mostra a solucao de forma visual, separando arquitetura,
processo de geracao/publicacao, pipeline Kedro gerada e fluxo de auditoria.

### Legenda visual das tecnologias

Os logos ficam concentrados na legenda para manter os diagramas proporcionais
e faceis de ler. Os fluxogramas usam cores corporativas e texto direto para
identificacao dos componentes.

| Tecnologia | Papel na solucao |
|---|---|
| <img src="https://cdn.simpleicons.org/mongodb/47A248" width="12" alt="MongoDB"/> MongoDB | Fonte operacional/editavel de metadados |
| <img src="https://cdn.simpleicons.org/databricks/FF3621" width="12" alt="Databricks"/> Databricks | Runtime de execucao e orquestracao do job |
| <img src="https://cdn.simpleicons.org/apachekedro/FFC900" width="12" alt="Kedro"/> Kedro | Framework de pipeline e execucao dos artefatos |
| <img src="https://cdn.simpleicons.org/apachespark/E25A1C" width="12" alt="Apache Spark"/> Apache Spark | Motor distribuido de processamento |
| <img src="https://cdn.simpleicons.org/microsoftazure/0078D4" width="12" alt="Microsoft Azure"/> ADLS / Azure | Armazenamento dos snapshots oficiais |
| <img src="https://cdn.simpleicons.org/python/3776AB" width="12" alt="Python"/> Python | Linguagem do gerador e dos nodes |
| <img src="https://cdn.simpleicons.org/yaml/CB171E" width="12" alt="YAML"/> YAML | Formato dos artefatos Kedro gerados |

### Arquitetura logica

```mermaid
%%{init: {"theme": "base", "themeVariables": {"background": "#FFFFFF", "primaryColor": "#FFFFFF", "primaryTextColor": "#1F1F1F", "primaryBorderColor": "#EC0000", "lineColor": "#6B7280", "secondaryColor": "#F7F7F7", "tertiaryColor": "#FFF5F5", "fontFamily": "Arial, Helvetica, sans-serif", "clusterBkg": "#FAFAFA", "clusterBorder": "#D1D5DB", "edgeLabelBackground": "#FFFFFF", "actorBkg": "#FFFFFF", "actorBorder": "#EC0000", "actorTextColor": "#1F1F1F", "activationBkgColor": "#FFF1F1", "activationBorderColor": "#EC0000"}}}%%
flowchart LR
    subgraph Metadata["Camada de Metadados"]
        MONGO["MongoDB<br/>Metadados editaveis"]
        JSON["JSON local<br/>Desenvolvimento e testes"]
    end

    subgraph Generator["Artifact Generator"]
        READER["Metadata Reader"]
        VALIDATOR["Metadata Validator<br/>(próximo passo)"]
        CATALOG["Catalog Generator<br/>catalog.yml"]
        PARAMS["Parameters Generator<br/>parameters.yml"]
        NODEGEN["Nodes Generator<br/>node.yaml"]
        PIPEDEF["Pipeline Definition<br/>pipeline.yaml"]
        SNAPSHOT["Snapshot Publisher<br/>manifest + checksums"]
    end

    subgraph Storage["Storage e Governanca"]
        ADLS["ADLS<br/>Snapshot oficial"]
        SUPPORT["Área de suporte<br/>Snapshot redigido"]
        AUDIT["Delta Audit Table<br/>Índice pesquisável"]
    end

    subgraph Runtime["Runtime de Execucao"]
        DBX["Databricks Job"]
        KEDRO["Kedro Run"]
        SPARK["Spark"]
        DELTA["Delta Tables<br/>Camada governada"]
    end

    MONGO --> READER
    JSON --> READER
    READER --> VALIDATOR
    VALIDATOR --> CATALOG
    VALIDATOR --> PARAMS
    VALIDATOR --> NODEGEN
    VALIDATOR --> PIPEDEF
    CATALOG --> SNAPSHOT
    PARAMS --> SNAPSHOT
    NODEGEN --> SNAPSHOT
    PIPEDEF --> SNAPSHOT
    SNAPSHOT --> ADLS
    SNAPSHOT --> SUPPORT
    SNAPSHOT --> AUDIT
    DBX --> KEDRO
    KEDRO --> SPARK
    SPARK --> DELTA
    ADLS --> DBX
    AUDIT --> DBX
```

### Fluxo de geracao, snapshot e execucao

```mermaid
%%{init: {"theme": "base", "themeVariables": {"background": "#FFFFFF", "primaryColor": "#FFFFFF", "primaryTextColor": "#1F1F1F", "primaryBorderColor": "#EC0000", "lineColor": "#6B7280", "secondaryColor": "#F7F7F7", "tertiaryColor": "#FFF5F5", "fontFamily": "Arial, Helvetica, sans-serif", "clusterBkg": "#FAFAFA", "clusterBorder": "#D1D5DB", "edgeLabelBackground": "#FFFFFF", "actorBkg": "#FFFFFF", "actorBorder": "#EC0000", "actorTextColor": "#1F1F1F", "activationBkgColor": "#FFF1F1", "activationBorderColor": "#EC0000"}}}%%
sequenceDiagram
    participant Job as Databricks Job
    participant Mongo as MongoDB / JSON
    participant Gen as Artifact Generator
    participant Mount as DBFS Mount
    participant ADLS as ADLS Snapshot
    participant Audit as Delta Audit
    participant Kedro as Kedro Runtime
    participant Delta as Delta Tables

    Job->>Mongo: Le metadados publicados
    Mongo-->>Gen: Input metadata + Output metadata
    Gen->>Gen: Valida metadados
    Gen->>Gen: Gera catalog.yml
    Gen->>Gen: Gera parameters.yml
    Gen->>Gen: Gera node.yaml e pipeline.yaml
    Gen->>Gen: Gera manifest.yml e checksums.json
    Gen->>Mount: Cria ou reutiliza mount point
    Mount-->>Gen: dbfs:/mnt/kedro-artifacts
    Gen->>ADLS: Publica snapshot da execucao
    Gen->>Audit: Registra artifact_uri e hashes
    Job->>Kedro: Executa kedro run --pipeline metadata_engine
    Kedro->>Delta: Le inputs Delta
    Kedro->>Delta: Grava output Delta
    Kedro->>Audit: Atualiza status e metricas
```

### Pipeline Kedro gerada

Exemplo visual da pipeline gerada a partir dos metadados atuais:

```mermaid
%%{init: {"theme": "base", "themeVariables": {"background": "#FFFFFF", "primaryColor": "#FFFFFF", "primaryTextColor": "#1F1F1F", "primaryBorderColor": "#EC0000", "lineColor": "#6B7280", "secondaryColor": "#F7F7F7", "tertiaryColor": "#FFF5F5", "fontFamily": "Arial, Helvetica, sans-serif", "clusterBkg": "#FAFAFA", "clusterBorder": "#D1D5DB", "edgeLabelBackground": "#FFFFFF", "actorBkg": "#FFFFFF", "actorBorder": "#EC0000", "actorTextColor": "#1F1F1F", "activationBkgColor": "#FFF1F1", "activationBorderColor": "#EC0000"}}}%%
flowchart TD
    ORDERS["input_orders<br/>raw.orders"] --> TORD["transform_orders_node<br/>apply_metadata_transformations"]
    CUSTOMERS["input_customers<br/>raw.customers"] --> TCUS["transform_customers_node<br/>apply_metadata_transformations"]

    PARAM_ORD["params<br/>metadata_engine.input_configs.orders"] --> TORD
    PARAM_CUS["params<br/>metadata_engine.input_configs.customers"] --> TCUS

    TORD --> ORD_TREATED["orders_treated"]
    TCUS --> CUS_TREATED["customers_treated"]

    ORD_TREATED --> BUILD["build_customer_orders_curated_node<br/>build_output_dataframe"]
    CUS_TREATED --> BUILD
    PARAM_OUT["params<br/>metadata_engine.output_config"] --> BUILD

    BUILD --> OUTPUT["output_customer_orders_curated<br/>main.curated.customer_orders"]
```

### Processo de montagem do output

```mermaid
%%{init: {"theme": "base", "themeVariables": {"background": "#FFFFFF", "primaryColor": "#FFFFFF", "primaryTextColor": "#1F1F1F", "primaryBorderColor": "#EC0000", "lineColor": "#6B7280", "secondaryColor": "#F7F7F7", "tertiaryColor": "#FFF5F5", "fontFamily": "Arial, Helvetica, sans-serif", "clusterBkg": "#FAFAFA", "clusterBorder": "#D1D5DB", "edgeLabelBackground": "#FFFFFF", "actorBkg": "#FFFFFF", "actorBorder": "#EC0000", "actorTextColor": "#1F1F1F", "activationBkgColor": "#FFF1F1", "activationBorderColor": "#EC0000"}}}%%
flowchart TD
    A["DataFrames tratados"] --> B["Seleciona input base<br/>is_base = true"]
    B --> C["Aplica aliases<br/>ord, cus, ..."]
    C --> D["Ordena joins por order"]
    D --> E["Monta condicoes de join"]
    E --> F["Executa joins Spark"]
    F --> G["Seleciona campos finais"]
    G --> H["Aplica casts finais"]
    H --> I["Retorna DataFrame de output"]
```

### Snapshot de execucao

```mermaid
%%{init: {"theme": "base", "themeVariables": {"background": "#FFFFFF", "primaryColor": "#FFFFFF", "primaryTextColor": "#1F1F1F", "primaryBorderColor": "#EC0000", "lineColor": "#6B7280", "secondaryColor": "#F7F7F7", "tertiaryColor": "#FFF5F5", "fontFamily": "Arial, Helvetica, sans-serif", "clusterBkg": "#FAFAFA", "clusterBorder": "#D1D5DB", "edgeLabelBackground": "#FFFFFF", "actorBkg": "#FFFFFF", "actorBorder": "#EC0000", "actorTextColor": "#1F1F1F", "activationBkgColor": "#FFF1F1", "activationBorderColor": "#EC0000"}}}%%
flowchart LR
    subgraph Local["Staging local / driver"]
        C["catalog.yml"]
        P["parameters.yml"]
        NODEYAML["node.yaml"]
        PIPEYAML["pipeline.yaml"]
        IN["input_metadata_snapshot.json"]
        OUT["output_metadata_snapshot.json"]
        CHK["checksums.json"]
        MAN["manifest.yml"]
    end

    subgraph ADLSPath["ADLS / DBFS Mount"]
        ROOT["dbfs:/mnt/kedro-artifacts"]
        ENV["env=prd"]
        PIPE["pipeline=customer_orders_curated"]
        EXEC["execution_id=..."]
    end

    C --> ROOT
    P --> ROOT
    NODEYAML --> ROOT
    PIPEYAML --> ROOT
    IN --> ROOT
    OUT --> ROOT
    CHK --> ROOT
    MAN --> ROOT
    ROOT --> ENV --> PIPE --> EXEC
```

### Fluxo de troubleshooting

```mermaid
%%{init: {"theme": "base", "themeVariables": {"background": "#FFFFFF", "primaryColor": "#FFFFFF", "primaryTextColor": "#1F1F1F", "primaryBorderColor": "#EC0000", "lineColor": "#6B7280", "secondaryColor": "#F7F7F7", "tertiaryColor": "#FFF5F5", "fontFamily": "Arial, Helvetica, sans-serif", "clusterBkg": "#FAFAFA", "clusterBorder": "#D1D5DB", "edgeLabelBackground": "#FFFFFF", "actorBkg": "#FFFFFF", "actorBorder": "#EC0000", "actorTextColor": "#1F1F1F", "activationBkgColor": "#FFF1F1", "activationBorderColor": "#EC0000"}}}%%
flowchart TD
    INC["Incidente / falha no job"] --> RUN["Identificar run_id ou execution_id"]
    RUN --> AUDIT["Consultar Delta Audit Table"]
    AUDIT --> URI["Obter artifact_uri"]
    URI --> MANIFEST["Abrir manifest.yml"]
    MANIFEST --> CHECK["Validar checksums"]
    CHECK --> INSPECT["Inspecionar catalog.yml<br/>parameters.yml<br/>node.yaml<br/>pipeline.yaml"]
    INSPECT --> DECISION{"Snapshot redigido e suficiente?"}
    DECISION -->|Sim| FIX["Diagnosticar e corrigir"]
    DECISION -->|Nao| BG["Acionar break-glass<br/>snapshot completo"]
    BG --> FIX
```

### Camadas de acesso aos artefatos

```mermaid
%%{init: {"theme": "base", "themeVariables": {"background": "#FFFFFF", "primaryColor": "#FFFFFF", "primaryTextColor": "#1F1F1F", "primaryBorderColor": "#EC0000", "lineColor": "#6B7280", "secondaryColor": "#F7F7F7", "tertiaryColor": "#FFF5F5", "fontFamily": "Arial, Helvetica, sans-serif", "clusterBkg": "#FAFAFA", "clusterBorder": "#D1D5DB", "edgeLabelBackground": "#FFFFFF", "actorBkg": "#FFFFFF", "actorBorder": "#EC0000", "actorTextColor": "#1F1F1F", "activationBkgColor": "#FFF1F1", "activationBorderColor": "#EC0000"}}}%%
flowchart LR
    subgraph Secure["ADLS produtivo restrito"]
        FULL["Snapshot completo<br/>metadados + artefatos"]
    end

    subgraph Support["Area de observabilidade"]
        REDACTED["Snapshot redigido<br/>sem secrets / dados sensiveis"]
        INDEX["Tabela Delta de auditoria<br/>ponteiros e hashes"]
    end

    subgraph Users["Usuarios"]
        ONCALL["Data engineering on-call"]
        PLATFORM["Data platform"]
        BREAK["Break-glass"]
    end

    FULL --> REDACTED
    FULL --> INDEX
    ONCALL --> REDACTED
    ONCALL --> INDEX
    PLATFORM --> FULL
    BREAK --> FULL
```

## Versoes base

As versoes declaradas em `pyproject.toml` sao:

```text
Python >= 3.11
Kedro >= 1.3.0
kedro-datasets >= 3.0.0
PySpark >= 3.5.0
Delta Spark >= 3.0.0
PyYAML >= 6.0.0
```

## Fluxo enterprise

O fluxo esperado em ambiente enterprise e:

```text
1. Ler metadados
   - MongoDB em producao
   - JSONs locais para desenvolvimento e testes

2. Validar metadados
   - inputs requeridos
   - output esperado
   - campos ativos
   - joins
   - tipos
   - destino

3. Gerar artefatos Kedro
   - catalog.yml
   - parameters.yml
   - pipeline.py

4. Criar snapshot da execucao
   - manifest.yml
   - checksums.json
   - input_metadata_snapshot.json
   - output_metadata_snapshot.json
   - copia dos artefatos gerados

5. Publicar snapshot
   - localmente para debug
   - ADLS via mount point em Databricks

6. Executar Kedro
   - kedro run
   - pipeline metadata_engine

7. Registrar auditoria
   - status
   - execution_id
   - artifact_uri
   - checksums
   - run id Databricks
```

Representacao visual:

```text
Metadata Source
    |
    v
Artifact Generator
    |
    v
Generated Kedro Artifacts
    |
    v
Snapshot Publisher
    |
    v
ADLS / DBFS Mount
    |
    v
Kedro Run on Databricks
```

## Estrutura do projeto

Estrutura principal atual:

```text
kedro_Template/
  conf/
    base/
      catalog.yml
      parameters.yml
      old/
    local/

  examples/
    metadata/
      orders_metadata.json
      customers_metadata.json
      output_metadata.json

  artifacts/
    generated_runs/

  src/
    kedro_template/
      artifact_generator/
        __init__.py
        main.py
        metadata_reader.py
        catalog_generator.py
        parameters_generator.py
        nodes_generator.py
        pipeline_definition_generator.py
        snapshot_publisher.py
        databricks_mount.py

      nodes/
        __init__.py
        input_transformations.py
        output_builder.py

      pipelines/
        __init__.py
        metadata_engine/
          __init__.py
          pipeline.py

      pipeline_registry.py
      __init__.py

  notebooks/
  tests/
  pyproject.toml
  README.md
```

### conf/

Pasta padrao do Kedro para configuracoes.

No fluxo deste projeto, os arquivos em `conf/base` sao gerados pelo
`artifact_generator`.

Arquivos importantes:

```text
conf/base/catalog.yml
conf/base/parameters.yml
```

`conf/base/old` guarda artefatos anteriores como referencia historica do
desenho inicial. Para um template final, essa pasta pode ser removida ou
movida para documentacao.

### examples/metadata/

Contem exemplos locais de metadados.

Essa pasta simula a fonte de metadados que, em producao, provavelmente sera
MongoDB.

Arquivos atuais:

```text
orders_metadata.json
customers_metadata.json
output_metadata.json
```

### artifacts/

Pasta de saida local para snapshots gerados.

Ela esta no `.gitignore` porque representa saida de execucao, nao codigo-fonte.

Exemplo:

```text
artifacts/generated_runs/
  env=dev/
    pipeline=customer_orders_curated/
      execution_id=final_reorg_validation/
        catalog.yml
        parameters.yml
        pipeline.py
        input_metadata_snapshot.json
        output_metadata_snapshot.json
        manifest.yml
        checksums.json
```

### src/kedro_template/artifact_generator/

Contem o gerador de artefatos Kedro.

Essa pasta nao contem nodes Spark de negocio. Ela contem codigo responsavel
por:

- ler metadados
- gerar YAMLs
- gerar pipeline Python
- criar snapshot
- publicar snapshot
- montar mount point Databricks

### src/kedro_template/nodes/

Contem os nodes executaveis pelo Kedro.

Aqui ficam as funcoes Spark que a pipeline gerada importa.

Separar `artifact_generator` de `nodes` e importante porque:

- gerador e codigo operacional
- nodes sao codigo de execucao de dados
- pipelines geradas devem depender dos nodes, nao do gerador

### src/kedro_template/pipelines/

Contem pipelines Kedro.

Neste template, `metadata_engine/pipeline.py` e gerado pelo
`artifact_generator`.

### pipeline_registry.py

Arquivo padrao do Kedro para registrar pipelines.

Ele tenta importar a pipeline gerada:

```python
from kedro_template.pipelines.metadata_engine.pipeline import create_pipeline
```

Se a pipeline ainda nao existir, retorna uma pipeline vazia para manter o
pacote importavel.

## Componentes principais

### artifact_generator/main.py

Entrypoint principal do gerador.

Ele executa o fluxo:

```text
read metadata
generate catalog.yml
generate parameters.yml
generate pipeline.py
resolve artifact destination
create snapshot
publish snapshot
```

Pode ser executado com:

```bash
python -m kedro_template.artifact_generator.main
```

Parametros principais:

```text
--input-metadata-path
--output-metadata-path
--catalog-output-path
--parameters-output-path
--node-output-path
--pipeline-definition-output-path
--artifact-base-uri
--mount-source
--mount-point
--tenant-id
--client-id
--client-secret-scope
--client-secret-key
--force-remount
--environment
--retention-class
--retention-days
--execution-id
```

### artifact_generator/metadata_reader.py

Le metadados de arquivos JSON locais.

Tambem possui funcao para leitura de MongoDB:

```python
read_metadata_from_mongo(...)
```

No fluxo local, a funcao principal e:

```python
read_metadata_from_files(...)
```

Quando o caminho de input e um diretorio, todos os JSONs que contem
`table_name` sao tratados como metadados de input.

O arquivo de output e lido separadamente.

### artifact_generator/catalog_generator.py

Gera `conf/base/catalog.yml`.

Para cada input, cria um dataset Kedro com nome:

```text
input_<table_name>
```

Para o output, cria:

```text
output_<output_name>
```

Exemplo gerado:

```yaml
input_customers:
  type: spark.SparkDataset
  file_format: delta
  table_name: customers
  schema_name: raw

input_orders:
  type: spark.SparkDataset
  file_format: delta
  table_name: orders
  schema_name: raw

output_customer_orders_curated:
  type: spark.SparkDataset
  file_format: delta
  table_name: customer_orders
  schema_name: curated
  save_args:
    mode: overwrite
```

Se o metadado tiver `path`, o catalogo usa `filepath`.

Se tiver `schema` e `table`, eles sao gerados em linhas separadas:

```yaml
table_name: customer_orders
schema_name: curated
```

### artifact_generator/parameters_generator.py

Gera `conf/base/parameters.yml`.

Esse arquivo guarda os metadados que serao passados aos nodes via parametros
Kedro.

Estrutura gerada:

```yaml
metadata_engine:
  output_name: customer_orders_curated
  input_configs:
    orders:
      ...
    customers:
      ...
  output_config:
    ...
```

### artifact_generator/nodes_generator.py

Gera:

```text
conf/base/node.yaml
```

O arquivo de nodes contem:

- um node de transformacao para cada input
- um node final para montar o output

Exemplo conceitual:

```text
input_orders
  -> transform_orders_node
  -> orders_treated

input_customers
  -> transform_customers_node
  -> customers_treated

orders_treated + customers_treated
  -> build_customer_orders_curated_node
  -> output_customer_orders_curated
```

### artifact_generator/pipeline_definition_generator.py

Gera:

```text
conf/base/pipeline.yaml
```

O arquivo de pipeline define a ordem de execucao dos nodes materializados em
`node.yaml`.

### artifact_generator/snapshot_publisher.py

Cria e publica o snapshot da execucao.

Arquivos incluidos no snapshot:

```text
catalog.yml
parameters.yml
node.yaml
pipeline.yaml
input_metadata_snapshot.json
output_metadata_snapshot.json
checksums.json
manifest.yml
```

O snapshot local fica em:

```text
artifacts/generated_runs/env=<env>/pipeline=<pipeline>/execution_id=<execution_id>/
```

Se o destino for `dbfs:/`, `abfs://` ou `abfss://`, o publisher usa
`dbutils.fs` e deve ser executado no Databricks.

### artifact_generator/databricks_mount.py

Responsavel por criar ou reutilizar mount point no Databricks.

Comportamento:

- se o mount nao existe, cria
- se existe e aponta para a mesma origem, reutiliza
- se existe e aponta para outra origem, falha por seguranca
- se `--force-remount` for informado, desmonta e monta novamente
- depois de montar, executa `dbutils.fs.refreshMounts()`

O mount e criado com OAuth service principal quando os parametros sao
informados:

```text
tenant_id
client_id
client_secret_scope
client_secret_key
```

O segredo e lido via Databricks Secrets:

```python
dbutils.secrets.get(scope=..., key=...)
```

## Modelo de metadados

O template usa dois tipos de metadados:

```text
Input metadata
Output metadata
```

### Input metadata

Exemplo:

```json
{
  "pipeline_name": "test_pipeline",
  "table_name": "orders",
  "schema": "raw",
  "table": "orders",
  "load": {
    "type": "full",
    "incremental_column": null
  },
  "filters": [],
  "fields": []
}
```

Responsabilidades:

- identificar a tabela de origem
- definir filtros
- definir campos de entrada
- definir tratamentos por campo
- definir tipos destino

Tratamentos suportados atualmente:

```text
trim
upper
lower
cast
replace
default
date_format
custom
```

Filtros suportados atualmente:

```text
=
<>
>
>=
<
<=
IN
NOT IN
IS NULL
IS NOT NULL
```

### Output metadata

Exemplo:

```json
{
  "pipeline_name": "test_pipeline",
  "output_name": "customer_orders_curated",
  "schema": "curated",
  "table": "customer_orders",
  "inputs": [],
  "joins": [],
  "fields": [],
  "derived_fields": [],
  "write": {
    "mode": "overwrite",
    "format": "delta",
    "partition_columns": []
  }
}
```

Responsabilidades:

- identificar destino final
- definir inputs participantes
- definir alias dos inputs
- definir joins
- definir campos finais
- definir campos derivados calculados apos os joins
- definir modo de escrita
- definir particionamento

Joins suportam operadores:

```text
=
<>
>
>=
<
<=
```

## Fluxo de atualizacao das collections

Esta secao descreve como evoluir os metadados no MongoDB sem perder
rastreabilidade e sem misturar contratos de pipelines diferentes.

O relacionamento principal entre as collections e:

```text
output_metadata.pipeline_name
  identifica a pipeline/output que sera gerado

output_metadata.inputs[].input_name
  aponta para input_metadata.table_name

input_metadata.pipeline_name
  garante que o input pertence a mesma pipeline
```

Na pratica, o gerador busca:

```javascript
db.output_metadata.findOne({
  pipeline_name: "test_pipeline"
})
```

e depois busca os inputs relacionados:

```javascript
db.input_metadata.find({
  pipeline_name: "test_pipeline",
  table_name: { $in: ["orders", "customers"] }
})
```

Portanto, todo documento de `input_metadata` usado por uma pipeline deve ter
o mesmo `pipeline_name` do documento em `output_metadata`.

### Regra geral de manutencao

Em producao, evite apagar documentos e campos como primeira acao.

Prefira:

```text
is_active = false
```

Essa pratica facilita troubleshooting, comparacao historica e rollback
operacional. Os snapshots preservam o que foi executado, mas o MongoDB deve
continuar legivel como camada operacional dos metadados atuais.

### Cenario 1: tabela nova + campo novo

Use este fluxo quando uma tabela nova passa a participar da pipeline.

Exemplo:

```text
Antes:
orders + customers

Depois:
orders + customers + payments
```

Passos recomendados:

1. Criar um novo documento em `input_metadata` para a tabela nova.
2. Adicionar a tabela em `output_metadata.inputs`.
3. Adicionar joins em `output_metadata.joins`, se a tabela precisar se
   relacionar com as demais.
4. Adicionar os campos finais em `output_metadata.fields`.
5. Revisar `derived_fields`, caso algum calculo final dependa da nova tabela.
6. Gerar os artefatos e conferir `node.yaml`, `pipeline.yaml`,
   `parameters.yml` e `catalog.yml`.

Exemplo de novo documento em `input_metadata`:

```json
{
  "pipeline_name": "test_pipeline",
  "table_name": "payments",
  "schema": "raw",
  "table": "payments",
  "is_active": true,
  "filters": [],
  "fields": [
    {
      "source_name": "payment_id",
      "target_name": "payment_id",
      "source_type": "string",
      "target_type": "string",
      "is_nullable": false,
      "is_active": true,
      "treatments": []
    }
  ]
}
```

Exemplo de inclusao em `output_metadata.inputs`:

```json
{
  "input_name": "payments",
  "alias": "pay",
  "is_base": false,
  "is_active": true
}
```

Exemplo de novo join:

```json
{
  "left_alias": "ord",
  "right_alias": "pay",
  "join_type": "left",
  "conditions": [
    {
      "left_column": "order_id",
      "operator": "=",
      "right_column": "order_id"
    }
  ],
  "order": 2,
  "is_active": true
}
```

Exemplo de campo final vindo da nova tabela:

```json
{
  "source_alias": "pay",
  "source_name": "payment_id",
  "target_name": "payment_id",
  "target_type": "string",
  "is_active": true
}
```

### Cenario 2: campo novo + tabela ja existe

Use este fluxo quando a tabela ja esta cadastrada e apenas um novo campo
precisa ser tratado ou publicado no output.

Passos recomendados:

1. Adicionar o campo em `input_metadata.fields` da tabela existente.
2. Adicionar o campo em `output_metadata.fields`, se ele deve aparecer na
   tabela final.
3. Adicionar ou revisar `output_metadata.derived_fields`, se o campo novo for
   usado em calculo pos-join.
4. Gerar os artefatos e conferir se o campo apareceu em `parameters.yml`.

Exemplo em `input_metadata.fields`:

```json
{
  "source_name": "order_status",
  "target_name": "order_status",
  "source_type": "string",
  "target_type": "string",
  "is_nullable": true,
  "is_active": true,
  "treatments": [
    {
      "type": "trim",
      "value": null,
      "order": 1
    }
  ]
}
```

Exemplo em `output_metadata.fields`:

```json
{
  "source_alias": "ord",
  "source_name": "order_status",
  "target_name": "order_status",
  "target_type": "string",
  "is_active": true
}
```

Exemplo de campo derivado usando o campo novo:

```json
{
  "target_name": "is_closed_order",
  "target_type": "boolean",
  "expression": "case when ord.order_status = 'CLOSED' then true else false end",
  "order": 10,
  "is_active": true
}
```

### Cenario 3: retirada de tabela

Use este fluxo quando uma tabela deixa de participar da pipeline.

Passos recomendados:

1. Remover ou desativar o item correspondente em `output_metadata.inputs`.
2. Desativar joins relacionados ao alias da tabela removida.
3. Desativar campos em `output_metadata.fields` que usam o alias da tabela.
4. Revisar `derived_fields`, porque expressoes podem depender desse alias.
5. Desativar o documento em `input_metadata` se ele nao for mais usado pela
   pipeline.
6. Gerar os artefatos e conferir se `node.yaml` nao possui mais o node da
   tabela retirada.

Exemplo de desativacao logica em `output_metadata.inputs`:

```json
{
  "input_name": "payments",
  "alias": "pay",
  "is_base": false,
  "is_active": false
}
```

Observacao importante: se o codigo ainda nao filtrar `is_active` em
`output_metadata.inputs`, a forma mais segura e remover o item do array
`inputs` e manter o historico no MongoDB por versionamento ou auditoria
externa.

Exemplo de join desativado:

```json
{
  "left_alias": "ord",
  "right_alias": "pay",
  "join_type": "left",
  "conditions": [],
  "order": 2,
  "is_active": false
}
```

Exemplo de input desativado:

```json
{
  "pipeline_name": "test_pipeline",
  "table_name": "payments",
  "schema": "raw",
  "table": "payments",
  "is_active": false
}
```

### Cenario 4: retirada de campos + tabela continua

Use este fluxo quando a tabela continua na pipeline, mas um ou mais campos
deixam de ser tratados ou publicados.

Passos recomendados:

1. Marcar o campo como `is_active = false` em `input_metadata.fields`, se ele
   nao deve mais ser lido/tratado.
2. Marcar o campo como `is_active = false` em `output_metadata.fields`, se ele
   nao deve mais sair na tabela final.
3. Revisar `derived_fields`, porque algum calculo pode depender do campo
   retirado.
4. Gerar os artefatos e conferir `parameters.yml`.

Exemplo em `input_metadata.fields`:

```json
{
  "source_name": "old_order_code",
  "target_name": "old_order_code",
  "source_type": "string",
  "target_type": "string",
  "is_nullable": true,
  "is_active": false,
  "treatments": []
}
```

Exemplo em `output_metadata.fields`:

```json
{
  "source_alias": "ord",
  "source_name": "old_order_code",
  "target_name": "old_order_code",
  "target_type": "string",
  "is_active": false
}
```

### Matriz de decisao

| Cenario | input_metadata | output_metadata.inputs | output_metadata.joins | output_metadata.fields | output_metadata.derived_fields |
|---|---|---|---|---|---|
| Tabela nova + campo novo | Criar documento | Adicionar input | Adicionar se necessario | Adicionar campos | Revisar/adicionar se necessario |
| Campo novo em tabela existente | Adicionar campo | Nao muda | Nao muda | Adicionar se sair no output | Revisar/adicionar se calculado |
| Retirada de tabela | Desativar se nao usada | Remover ou desativar | Desativar joins do alias | Desativar campos do alias | Revisar expressoes |
| Retirada de campos | Desativar campos | Nao muda | Nao muda | Desativar campos | Revisar expressoes |

### Checklist antes de publicar

Antes de promover uma alteracao de metadados, valide:

- `pipeline_name` esta igual em `output_metadata` e nos respectivos
  documentos de `input_metadata`.
- Todo `output_metadata.inputs[].input_name` existe como
  `input_metadata.table_name`.
- Todo `source_alias` em `fields` existe em `output_metadata.inputs`.
- Todo alias usado em `joins` existe em `output_metadata.inputs`.
- Toda expressao em `derived_fields.expression` usa colunas/aliases validos.
- Apenas uma tabela esta marcada como `is_base = true`.
- Campos removidos nao sao usados por joins ou campos derivados.
- `partition_columns` existem no output final, seja em `fields` ou
  `derived_fields`.
- O snapshot foi gerado e possui `manifest.yml` e `checksums.json`.

## Artefatos gerados

### catalog.yml

Define datasets Kedro de entrada e saida.

E usado pelo Kedro para ler e salvar dados.

### parameters.yml

Contem os metadados materializados como parametros Kedro.

Os nodes recebem esses parametros em runtime.

### pipeline.py

Contem a DAG Kedro gerada.

Esse arquivo e importante para debug porque permite ver exatamente:

- quais nodes foram criados
- quais inputs cada node recebe
- quais outputs cada node produz
- qual funcao cada node executa

### manifest.yml

Documento central de auditoria do snapshot.

Contem:

```text
execution_id
environment
pipeline_name
generated_at
artifact_uri
target
retention
files
checksums
status
```

### checksums.json

Contem SHA-256 dos arquivos do snapshot.

Serve para:

- detectar alteracoes indevidas
- garantir integridade
- comparar execucoes
- suportar replay confiavel

## Snapshot e publicacao no ADLS

O snapshot e a copia oficial dos artefatos usados em uma execucao.

O objetivo e garantir que a execucao nao dependa do estado atual dos
metadados.

Regra importante:

```text
MongoDB ou JSON sao fontes configuraveis.
Snapshot no ADLS e a fonte oficial do que foi executado.
```

Estrutura recomendada no ADLS:

```text
dbfs:/mnt/kedro-artifacts/
  env=prd/
    pipeline=customer_orders_curated/
      execution_id=20260502_153000_customer_orders_curated_ab12cd34/
        catalog.yml
        parameters.yml
        pipeline.py
        input_metadata_snapshot.json
        output_metadata_snapshot.json
        manifest.yml
        checksums.json
```

## Mount point em Databricks

Em job clusters Databricks, e comum precisar montar o ADLS em tempo de
execucao.

O gerador suporta isso via:

```text
--mount-source
--mount-point
--tenant-id
--client-id
--client-secret-scope
--client-secret-key
```

Exemplo:

```bash
python -m kedro_template.artifact_generator.main \
  --mount-source abfss://kedro-artifacts@storageaccount.dfs.core.windows.net/ \
  --mount-point /mnt/kedro-artifacts \
  --tenant-id <tenant-id> \
  --client-id <client-id> \
  --client-secret-scope data-platform \
  --client-secret-key sp-client-secret \
  --environment prd \
  --retention-class production \
  --retention-days 730
```

O snapshot sera publicado em:

```text
dbfs:/mnt/kedro-artifacts/env=prd/pipeline=<pipeline>/execution_id=<execution_id>/
```

### Sobre --force-remount

Use `--force-remount` apenas quando for intencional substituir um mount point
existente.

Sem esse parametro, se o mount existir apontando para outra origem, o processo
falha por seguranca.

## Retencao de snapshots

Os snapshots sao pequenos, geralmente KBs ou poucos MBs por execucao.

Mesmo assim, a retencao deve ser explicita.

Politica inicial recomendada:

```text
dev:
  30 dias

hml:
  90 dias

prd:
  730 dias

prd critical:
  1825 dias

failed prd:
  180 dias
```

O `manifest.yml` registra:

```yaml
retention:
  class: production
  days: 730
  expires_at: "..."
  legal_hold: false
```

Recomendacao enterprise:

- nao apagar snapshots em `legal_hold`
- manter sempre as ultimas N execucoes bem-sucedidas por pipeline
- preservar execucoes associadas a incidentes
- controlar limpeza por job que consulte tabela de auditoria Delta

## Troubleshooting e auditoria

Durante um incidente, o time deve conseguir responder rapidamente:

```text
Qual pipeline rodou?
Quais metadados foram usados?
Qual catalog.yml foi usado?
Qual parameters.yml foi usado?
Qual pipeline.py foi gerado?
Qual era o destino?
Quais inputs participaram?
O artefato foi alterado?
Qual execution_id corresponde ao run?
```

O snapshot responde essas perguntas.

Fluxo recomendado:

```text
1. Localizar execution_id ou Databricks run_id
2. Consultar tabela de auditoria
3. Abrir artifact_uri
4. Ver manifest.yml
5. Comparar checksums
6. Inspecionar pipeline.py, catalog.yml e parameters.yml
7. Reexecutar, se necessario, com o mesmo snapshot
```

## Como executar localmente

### 1. Configurar PYTHONPATH

```powershell
$env:PYTHONPATH='src'
```

### 2. Gerar artefatos e snapshot local

```powershell
python -m kedro_template.artifact_generator.main --execution-id local_debug
```

Saida esperada:

```text
Generated artifact snapshot: artifacts/generated_runs/env=dev/pipeline=customer_orders_curated/execution_id=local_debug
```

### 3. Validar sintaxe Python

```powershell
python -m compileall src
```

## Como executar no Databricks

Exemplo completo:

```bash
python -m kedro_template.artifact_generator.main \
  --input-metadata-path examples/metadata \
  --output-metadata-path examples/metadata/output_metadata.json \
  --mount-source abfss://kedro-artifacts@storageaccount.dfs.core.windows.net/ \
  --mount-point /mnt/kedro-artifacts \
  --tenant-id <tenant-id> \
  --client-id <client-id> \
  --client-secret-scope data-platform \
  --client-secret-key sp-client-secret \
  --environment prd \
  --retention-class production \
  --retention-days 730
```

Depois da geracao, executar Kedro:

```bash
kedro run --pipeline metadata_engine
```

Em um workflow Databricks, isso pode ser dividido em duas tasks:

```text
Task 1:
  gerar artefatos e publicar snapshot

Task 2:
  executar kedro run
```

Ou em uma unica task:

```text
gerar artefatos
publicar snapshot
executar kedro run
```

## Como o Kedro executa a pipeline gerada

O Kedro usa `pipeline_registry.py`.

Esse arquivo registra:

```text
metadata_engine
__default__
```

A pipeline gerada le datasets:

```text
input_orders
input_customers
```

Aplica transformacoes:

```text
transform_orders_node
transform_customers_node
```

Monta o output:

```text
build_customer_orders_curated_node
```

E grava:

```text
output_customer_orders_curated
```

## Decisoes arquiteturais

### 1. Gerar artefatos em vez de montar pipeline somente em memoria

Motivo:

- melhora auditoria
- melhora debug
- permite replay
- reduz magia de runtime
- aproxima da pratica enterprise de arquivos estaticos

### 2. Snapshot no ADLS

Motivo:

- ADLS e nativo no ecossistema Databricks
- suporta governanca e controle de acesso
- e adequado para arquivos
- permite retencao por path
- facilita replay

### 3. Mount point em tempo de execucao

Motivo:

- job clusters podem ser efemeros
- mount pode nao existir no cluster
- credenciais devem vir de secrets
- processo precisa ser reprodutivel

### 4. Separar generator de nodes

Motivo:

- `artifact_generator` e codigo operacional
- `nodes` e codigo executado pelo Kedro
- pipeline gerada deve depender de nodes estaveis
- evita acoplamento desnecessario

### 5. Metadados nao devem virar linguagem de programacao

Metadados devem parametrizar padroes.

Bons usos:

- filtros simples
- casts
- renomeacao
- selecao de campos
- joins parametrizados
- modo de escrita

Evitar:

- regras de negocio muito complexas
- algoritmos
- logica de dominio extensa
- SQLs gigantes escondidos em JSON

Para casos complexos, crie uma funcao Python/Spark versionada e referencie nos
metadados.

## Riscos e mitigacoes

### Risco: metadados inconsistentes

Mitigacao:

- validacao antes de gerar artefatos
- schema formal dos metadados
- testes unitarios
- status de aprovacao no MongoDB

### Risco: snapshot nao publicado

Mitigacao:

- falhar execucao se snapshot nao for publicado
- gravar logs
- registrar auditoria
- checar existencia do `manifest.yml`

### Risco: mount point errado

Mitigacao:

- validar origem existente
- falhar se o mount aponta para source diferente
- usar `--force-remount` somente de forma controlada

### Risco: acesso excessivo aos artefatos

Mitigacao:

- snapshot completo em area restrita
- snapshot redigido em area de suporte
- secrets nunca salvos em snapshot
- break-glass para incidente critico

### Risco: artefatos gerados sobrescreverem codigo manual

Mitigacao:

- delimitar pasta de pipeline gerada
- documentar que `metadata_engine/pipeline.py` e gerado
- manter geracao idempotente
- versionar o gerador, nao editar manualmente o artefato

## Proximos passos recomendados

1. Criar validacao formal dos metadados com Pydantic.
2. Implementar leitura principal a partir do MongoDB.
3. Criar status de metadados: `draft`, `validated`, `approved`, `published`.
4. Criar tabela Delta de auditoria de geracao e execucao.
5. Criar job de retencao dos snapshots no ADLS.
6. Criar versao redigida dos snapshots para troubleshooting.
7. Adicionar testes unitarios para os generators.
8. Adicionar testes de integracao em Databricks.
9. Suportar multiplas pipelines geradas.
10. Avaliar geracao de `nodes.yml` e `pipelines.yml` caso o padrao enterprise atual exija esses arquivos.

## Comandos uteis

Gerar artefatos localmente:

```powershell
$env:PYTHONPATH='src'
python -m kedro_template.artifact_generator.main --execution-id local_debug
```

Compilar codigo:

```powershell
python -m compileall src
```

Executar Kedro:

```bash
kedro run --pipeline metadata_engine
```

Executar gerador com mount point:

```bash
python -m kedro_template.artifact_generator.main \
  --mount-source abfss://kedro-artifacts@storageaccount.dfs.core.windows.net/ \
  --mount-point /mnt/kedro-artifacts \
  --tenant-id <tenant-id> \
  --client-id <client-id> \
  --client-secret-scope data-platform \
  --client-secret-key sp-client-secret \
  --environment prd \
  --retention-class production \
  --retention-days 730
```




