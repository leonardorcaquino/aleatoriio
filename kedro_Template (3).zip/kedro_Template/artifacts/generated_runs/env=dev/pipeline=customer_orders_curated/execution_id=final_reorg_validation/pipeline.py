from kedro.pipeline import Pipeline, node, pipeline

from kedro_template.nodes.input_transformations import apply_metadata_transformations
from kedro_template.nodes.output_builder import build_output_dataframe


def build_customer_orders_curated(
    orders, customers,
    output_config,
):
    dfs = {
        "orders": orders,
        "customers": customers,
    }
    return build_output_dataframe(dfs, output_config)


def create_pipeline(**kwargs) -> Pipeline:
    return pipeline(
        [

        node(
            func=apply_metadata_transformations,
            inputs=[
                "input_orders",
                "params:metadata_engine.input_configs.orders"
            ],
            outputs="orders_treated",
            name="transform_orders_node"
        ),

        node(
            func=apply_metadata_transformations,
            inputs=[
                "input_customers",
                "params:metadata_engine.input_configs.customers"
            ],
            outputs="customers_treated",
            name="transform_customers_node"
        ),

            node(
                func=build_customer_orders_curated,
                inputs=[
                    "orders_treated",
                    "customers_treated",
                    "params:metadata_engine.output_config"
                ],
                outputs="output_customer_orders_curated",
                name="build_customer_orders_curated_node"
            )
        ]
    )
